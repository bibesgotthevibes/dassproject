import unittest
import json
import threading
from datetime import datetime, timedelta
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../src'))

from FoodDelivery import (
    MenuService, OrderService, UserService, DeliveryAgentService,
    MenuItem, Order, User, DeliveryAgent, OrderItem,
    OrderType, OrderStatus, DeliveryAgentStatus
)

class FoodDeliverySystemTest(unittest.TestCase):
    def setUp(self):
        """Set up test environment before each test"""
        self.temp_dir = "test_data"
        if not os.path.exists(self.temp_dir):
            os.makedirs(self.temp_dir)

        # Initialize services
        self.menu_service = MenuService(os.path.join(self.temp_dir, "menu.json"))
        self.user_service = UserService(os.path.join(self.temp_dir, "users.json"))
        self.delivery_service = DeliveryAgentService(os.path.join(self.temp_dir, "delivery_agents.json"))
        self.order_service = OrderService(self.menu_service, os.path.join(self.temp_dir, "orders.json"))

    def tearDown(self):
        """Clean up after each test"""
        for file in os.listdir(self.temp_dir):
            os.remove(os.path.join(self.temp_dir, file))
        os.rmdir(self.temp_dir)

    def test_menu_item_validation(self):
        """Test MenuItem validation"""
        with self.assertRaises(ValueError):
            MenuItem("", "", "", -10.0, "")

    def test_order_item_calculations(self):
        """Test OrderItem price calculations"""
        menu_item = MenuItem("1", "Test", "Desc", 10.0, "Cat")
        order_item = OrderItem(menu_item, 3)
        self.assertEqual(order_item.get_total_price(), 30.0)

    def test_order_time_calculations(self):
        """Test Order time calculations"""
        order = Order("1", "cust1", [], OrderType.HOME_DELIVERY, "Test Address")
        order.set_estimated_delivery_time(30)
        self.assertIsInstance(order.estimated_delivery_time, datetime)
        self.assertNotEqual(order.get_time_remaining(), "Not estimated yet")

    def test_menu_service_initialization(self):
        items = self.menu_service.get_all_items()
        self.assertGreater(len(items), 0)
        self.assertIsInstance(items[0], MenuItem)

    def test_menu_service_crud(self):
        new_item = self.menu_service.add_item("Test Pizza", "Test Description", 9.99, "Pizza")
        self.assertEqual(new_item.name, "Test Pizza")

        item = self.menu_service.get_item_by_id(new_item.id)
        self.assertEqual(item.price, 9.99)

        updated = self.menu_service.update_item(new_item.id, "Updated Pizza", "New Desc", 10.99, "Pizza")
        self.assertTrue(updated)

        deleted = self.menu_service.remove_item(new_item.id)
        self.assertTrue(deleted)

    def test_menu_service_categories(self):
        self.menu_service.add_item("Pizza 1", "Desc", 10.0, "Pizza")
        self.menu_service.add_item("Pizza 2", "Desc", 12.0, "Pizza")
        self.menu_service.add_item("Burger 1", "Desc", 8.0, "Burger")

        items = self.menu_service.get_all_items()
        categories = set(item.category for item in items)
        self.assertIn("Pizza", categories)
        self.assertIn("Burger", categories)

    def test_order_service_validation(self):
        with self.assertRaises(ValueError):
            self.order_service.create_order(
                "",  # Invalid customer ID
                [],  # Empty items
                OrderType.HOME_DELIVERY
            )

    def test_delivery_agent_availability(self):
        agent = self.delivery_service.add_agent("Test", "1234")
        self.assertIn(agent, self.delivery_service.get_available_agents())

        self.delivery_service.assign_order_to_agent(agent.id, "order1")
        self.assertNotIn(agent, self.delivery_service.get_available_agents())

        self.delivery_service.complete_agent_order(agent.id)
        self.assertIn(agent, self.delivery_service.get_available_agents())

    def test_integration(self):
        # Create test data
        user = self.user_service.register_user("Test User", "555-1234", "Test Address")
        menu_item = self.menu_service.add_item("Test Item", "Test Desc", 9.99, "Test")

        # Create order
        order = self.order_service.create_order(
            user.id,
            [MenuItem(menu_item.id, menu_item.name, menu_item.description,
                     menu_item.price, menu_item.category)],
            OrderType.HOME_DELIVERY,
            user.address
        )

        # Test delivery flow
        agent = self.delivery_service.add_agent("Test Agent", "555-1234")
        success = self.order_service.assign_delivery_agent(order.id, agent.id)
        self.assertTrue(success)

        self.order_service.update_order_status(order.id, OrderStatus.DELIVERED)
        self.delivery_service.complete_agent_order(agent.id)

        # Verify final state
        order = self.order_service.get_order_by_id(order.id)
        agent = self.delivery_service.get_agent_by_id(agent.id)
        self.assertEqual(order.status, OrderStatus.DELIVERED)
        self.assertEqual(agent.status, DeliveryAgentStatus.AVAILABLE)

    def test_concurrent_order_processing(self):
        menu_item = self.menu_service.add_item("Test", "Desc", 10.0, "Test")
        orders = []

        # Create test orders
        for i in range(5):
            order = self.order_service.create_order(
                f"cust{i}",
                [MenuItem(menu_item.id, menu_item.name, menu_item.description,
                         menu_item.price, menu_item.category)],
                OrderType.HOME_DELIVERY,
                f"Address {i}"
            )
            orders.append(order)

        def process_order(order_id):
            self.order_service.update_order_status(order_id, OrderStatus.PREPARING)
            self.order_service.update_order_status(order_id, OrderStatus.DELIVERED)

        # Test concurrent processing
        threads = []
        for order in orders:
            t = threading.Thread(target=process_order, args=(order.id,))
            threads.append(t)
            t.start()

        for t in threads:
            t.join()

        # Verify results
        for order in orders:
            updated_order = self.order_service.get_order_by_id(order.id)
            self.assertEqual(updated_order.status, OrderStatus.DELIVERED)

    def test_system_load(self):
        """Test system performance under load"""
        menu_item = self.menu_service.add_item("Test Item", "Description", 9.99, "Test")
        order_count = 100
        start_time = datetime.now()

        def create_bulk_orders():
            for i in range(order_count):
                self.order_service.create_order(
                    f"customer_{i}",
                    [MenuItem(menu_item.id, menu_item.name, menu_item.description,
                             menu_item.price, menu_item.category)],
                    OrderType.TAKEAWAY
                )

        # Create orders in multiple threads
        threads = []
        for _ in range(4):
            t = threading.Thread(target=create_bulk_orders)
            threads.append(t)
            t.start()

        for t in threads:
            t.join()

        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()

        # Verify results
        all_orders = self.order_service.get_all_orders()
        self.assertGreaterEqual(len(all_orders), order_count)
        self.assertLess(duration, 60)  # Should complete within reasonable time

if __name__ == '__main__':
    unittest.main()