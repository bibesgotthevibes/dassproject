import os
import json
import time
import uuid
import datetime
import threading
from enum import Enum
from typing import List, Optional
import fcntl  # Note: works on Unix; for Windows you could use msvcrt

# ----------------------------
# FileLock for persistence
# ----------------------------
class FileLock:
    def __init__(self, lock_path):
        self.lock_path = lock_path
        self.handle = None

    def __enter__(self):
        self.handle = open(self.lock_path, 'w')
        fcntl.flock(self.handle, fcntl.LOCK_EX)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.handle:
            fcntl.flock(self.handle, fcntl.LOCK_UN)
            self.handle.close()

# ----------------------------
# Enums
# ----------------------------
class OrderType(Enum):
    HOME_DELIVERY = "Home Delivery"
    TAKEAWAY = "Takeaway"

class OrderStatus(Enum):
    PLACED = "Placed"
    PREPARING = "Preparing"
    READY_FOR_PICKUP = "Ready for Pickup"
    OUT_FOR_DELIVERY = "Out for Delivery"
    DELIVERED = "Delivered"
    COMPLETED = "Completed"
    CANCELLED = "Cancelled"

class DeliveryAgentStatus(Enum):
    AVAILABLE = "Available"
    BUSY = "Busy"
    OFFLINE = "Offline"

# ----------------------------
# Data Models
# ----------------------------
class MenuItem:
    def __init__(self, id: str, name: str, description: str, price: float, category: str):
        if price <= 0:
            raise ValueError("Price must be positive")
        self.id = id
        self.name = name
        self.description = description
        self.price = price
        self.category = category

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "price": self.price,
            "category": self.category
        }

    @classmethod
    def from_dict(cls, data, menu_items=None):
        try:
            price = float(data.get("price"))
        except (TypeError, ValueError):
            raise ValueError("Invalid price value")
        if price <= 0:
            raise ValueError("Price must be positive")
        return cls(
            id=data.get("id"),
            name=data.get("name"),
            description=data.get("description"),
            price=price,
            category=data.get("category")
        )




class OrderItem:
    def __init__(self, menu_item: MenuItem, quantity: int):
        self.menu_item = menu_item
        self.quantity = quantity

    def get_total_price(self):
        return self.menu_item.price * self.quantity

    def to_dict(self):
        return {
            "menu_item": self.menu_item.to_dict(),
            "quantity": self.quantity
        }

    @classmethod
    def from_dict(cls, data, menu_items):
        try:
            menu_item_data = data.get("menu_item")
            menu_item = None
            if menu_item_data and isinstance(menu_item_data, dict):
                # Try to find the menu item in the current menu list.
                menu_item = next((item for item in menu_items if item.id == menu_item_data.get("id")), None)
            if menu_item is None and menu_item_data and isinstance(menu_item_data, dict):
                # If not found, reconstruct the MenuItem from the stored data, passing an empty list.
                menu_item = MenuItem.from_dict(menu_item_data, [])
            return cls(
                menu_item=menu_item,
                quantity=data.get("quantity", 0)
            )
        except Exception as e:
            # Log the error and return a fallback OrderItem so that the order can load.
            print("Error loading OrderItem:", e)
            fallback = MenuItem("unknown", "Unknown Item", "Item not found", 0.0, "Unknown")
            return cls(menu_item=fallback, quantity=data.get("quantity", 0))



class Order:
    def __init__(self,
                 id: str,
                 customer_id: str,
                 items: List[OrderItem],
                 order_type: OrderType,
                 address: Optional[str] = None,
                 status: OrderStatus = OrderStatus.PLACED,
                 delivery_agent_id: Optional[str] = None):
        self.id = id
        self.customer_id = customer_id
        self.items = items
        self.order_type = order_type
        self.address = address
        self.status = status
        self.delivery_agent_id = delivery_agent_id
        self.placed_time = datetime.datetime.now()
        self.estimated_delivery_time = None
        self.completed_time = None

    def get_total_amount(self):
        return sum(item.get_total_price() for item in self.items)

    def set_estimated_delivery_time(self, minutes: int):
        self.estimated_delivery_time = self.placed_time + datetime.timedelta(minutes=minutes)

    def get_time_remaining(self):
        if not self.estimated_delivery_time:
            return "Not estimated yet"
        time_left = self.estimated_delivery_time - datetime.datetime.now()
        if time_left.total_seconds() <= 0:
            return "Due any moment"
        minutes_left = int(time_left.total_seconds() / 60)
        return f"{minutes_left} minutes"

    def update_status(self, status: OrderStatus):
        self.status = status
        if status in [OrderStatus.DELIVERED, OrderStatus.COMPLETED]:
            self.completed_time = datetime.datetime.now()

    def to_dict(self):
        return {
            "id": self.id,
            "customer_id": self.customer_id,
            "items": [item.to_dict() for item in self.items],
            "order_type": self.order_type.value,
            "address": self.address,
            "status": self.status.value,
            "delivery_agent_id": self.delivery_agent_id,
            "placed_time": self.placed_time.isoformat(),
            "estimated_delivery_time": self.estimated_delivery_time.isoformat() if self.estimated_delivery_time else None,
            "completed_time": self.completed_time.isoformat() if self.completed_time else None
        }

    @classmethod
    def from_dict(cls, data, menu_items):
        items = [OrderItem.from_dict(item_data, menu_items) for item_data in data.get("items", [])]
        order = cls(
            id=data.get("id"),
            customer_id=data.get("customer_id"),
            items=items,
            order_type=OrderType(data.get("order_type")),
            address=data.get("address"),
            status=OrderStatus(data.get("status")),
            delivery_agent_id=data.get("delivery_agent_id")
        )
        order.placed_time = datetime.datetime.fromisoformat(data.get("placed_time"))
        if data.get("estimated_delivery_time"):
            order.estimated_delivery_time = datetime.datetime.fromisoformat(data.get("estimated_delivery_time"))
        if data.get("completed_time"):
            order.completed_time = datetime.datetime.fromisoformat(data.get("completed_time"))
        return order

class DeliveryAgent:
    def __init__(self, id: str, name: str, phone: str):
        self.id = id
        self.name = name
        self.phone = phone
        self.status = DeliveryAgentStatus.AVAILABLE
        self.current_order_id = None

    def assign_order(self, order_id: str):
        self.current_order_id = order_id
        self.status = DeliveryAgentStatus.BUSY

    def complete_order(self):
        self.current_order_id = None
        self.status = DeliveryAgentStatus.AVAILABLE

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "phone": self.phone,
            "status": self.status.value,
            "current_order_id": self.current_order_id
        }

    @classmethod
    def from_dict(cls, data):
        agent = cls(
            id=data.get("id"),
            name=data.get("name"),
            phone=data.get("phone")
        )
        agent.status = DeliveryAgentStatus(data.get("status"))
        agent.current_order_id = data.get("current_order_id")
        return agent

class User:
    def __init__(self, id: str, name: str, phone: str, address: str, is_admin: bool = False):
        self.id = id
        self.name = name
        self.phone = phone
        self.address = address
        self.is_admin = is_admin

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "phone": self.phone,
            "address": self.address,
            "is_admin": self.is_admin
        }

    @classmethod
    def from_dict(cls, data):
        # Generate a new ID if it's missing or None
        user_id = data.get("id") or str(uuid.uuid4())
        return cls(
            id=user_id,
            name=data.get("name"),
            phone=data.get("phone"),
            address=data.get("address"),
            is_admin=data.get("is_admin", False)
        )

# ----------------------------
# Service Classes with File Locking
# ----------------------------
class MenuService:
    def __init__(self, data_path: str = "data/menu.json"):
        self.data_path = data_path
        self.lock_path = data_path + ".lock"
        self.menu_items = []
        self.load_menu()

    def load_menu(self):
        os.makedirs(os.path.dirname(self.data_path), exist_ok=True)
        if os.path.exists(self.data_path):
            try:
                with FileLock(self.lock_path):
                    with open(self.data_path, 'r') as file:
                        items_data = json.load(file)
                        self.menu_items = [MenuItem.from_dict(item) for item in items_data]
            except Exception as e:
                print("Error loading menu:", e)
                self.initialize_default_menu()
        else:
            self.initialize_default_menu()

    def initialize_default_menu(self):
        default_items = [
            MenuItem(str(uuid.uuid4()), "Margherita Pizza", "Classic cheese and tomato pizza", 9.99, "Pizza"),
            MenuItem(str(uuid.uuid4()), "Pepperoni Pizza", "Pizza with pepperoni", 11.99, "Pizza"),
            MenuItem(str(uuid.uuid4()), "Vegetarian Pizza", "Pizza with assorted vegetables", 10.99, "Pizza"),
            MenuItem(str(uuid.uuid4()), "Chicken Burger", "Grilled chicken with lettuce and mayo", 8.99, "Burger"),
            MenuItem(str(uuid.uuid4()), "Beef Burger", "Beef patty with cheese and pickles", 9.99, "Burger"),
            MenuItem(str(uuid.uuid4()), "Fries", "Crispy potato fries", 3.99, "Sides"),
            MenuItem(str(uuid.uuid4()), "Cola", "Refreshing cola drink", 1.99, "Drinks"),
            MenuItem(str(uuid.uuid4()), "Water", "Mineral water", 0.99, "Drinks")
        ]
        self.menu_items = default_items
        self.save_menu()

    def save_menu(self):
        os.makedirs(os.path.dirname(self.data_path), exist_ok=True)
        with FileLock(self.lock_path):
            with open(self.data_path, 'w') as file:
                json.dump([item.to_dict() for item in self.menu_items], file)

    def get_all_items(self):
        self.load_menu()
        return self.menu_items

    def get_item_by_id(self, item_id: str):
        return next((item for item in self.menu_items if item.id == item_id), None)

    def add_item(self, name: str, description: str, price: float, category: str):
        new_item = MenuItem(str(uuid.uuid4()), name, description, price, category)
        self.menu_items.append(new_item)
        self.save_menu()
        return new_item

    def update_item(self, item_id: str, name: str, description: str, price: float, category: str):
        item = self.get_item_by_id(item_id)
        if item:
            item.name = name
            item.description = description
            item.price = price
            item.category = category
            self.save_menu()
            return True
        return False

    def remove_item(self, item_id: str):
        item = self.get_item_by_id(item_id)
        if item:
            self.menu_items.remove(item)
            self.save_menu()
            return True
        return False

class OrderService:
    def __init__(self, menu_service: MenuService, data_path: str = "data/orders.json"):
        self.data_path = data_path
        self.lock_path = data_path + ".lock"
        self.orders = []
        self.menu_service = menu_service
        self.load_orders()

    def load_orders(self):
        os.makedirs(os.path.dirname(self.data_path), exist_ok=True)
        if os.path.exists(self.data_path):
            try:
                with FileLock(self.lock_path):
                    with open(self.data_path, 'r') as file:
                        orders_data = json.load(file)
                        if not isinstance(orders_data, list):
                            orders_data = []
                        menu_items = self.menu_service.get_all_items()
                        valid_orders = []
                        for order in orders_data:
                            if isinstance(order, dict):
                                try:
                                    valid_orders.append(Order.from_dict(order, menu_items))
                                except Exception:
                                    pass  # silently skip invalid order entries
                            else:
                                pass  # silently skip non-dictionary entries
                        self.orders = valid_orders
            except Exception:
                self.orders = []
        else:
            self.orders = []




    def save_orders(self):
        os.makedirs(os.path.dirname(self.data_path), exist_ok=True)
        with FileLock(self.lock_path):
            with open(self.data_path, 'w') as file:
                json.dump([order.to_dict() for order in self.orders], file)

    def create_order(self, customer_id: str, items: List[OrderItem], order_type: OrderType, address: Optional[str] = None):
        if not items:
            raise ValueError("Order must have at least one item")
        order_id = str(uuid.uuid4())
        new_order = Order(order_id, customer_id, items, order_type, address)
        if order_type == OrderType.HOME_DELIVERY:
            estimated_minutes = 15 + (5 * len(items))
        else:
            estimated_minutes = 10 + (3 * len(items))
        new_order.set_estimated_delivery_time(estimated_minutes)
        self.orders.append(new_order)
        self.save_orders()
        return new_order

    def get_all_orders(self):
        self.load_orders()  # Reload orders from disk
        return self.orders

    def get_order_by_id(self, order_id: str):
        return next((order for order in self.orders if order.id == order_id), None)

    def get_orders_by_customer(self, customer_id: str):
        self.load_orders()  # Reload orders from disk
        return [order for order in self.orders if order.customer_id == customer_id]


    def get_active_orders(self):
        self.load_orders()  # Reload orders from disk
        return [order for order in self.orders if order.status not in [OrderStatus.DELIVERED, OrderStatus.COMPLETED, OrderStatus.CANCELLED]]

    def update_order_status(self, order_id: str, status: OrderStatus):
        order = self.get_order_by_id(order_id)
        if order:
            order.update_status(status)
            self.save_orders()
            return True
        return False

    def assign_delivery_agent(self, order_id: str, agent_id: str):
        order = self.get_order_by_id(order_id)
        if order and order.order_type == OrderType.HOME_DELIVERY:
            order.delivery_agent_id = agent_id
            self.save_orders()
            return True
        return False

class DeliveryAgentService:
    def __init__(self, data_path: str = "data/delivery_agents.json"):
        self.data_path = data_path
        self.lock_path = data_path + ".lock"
        self.agents = []
        self.load_agents()

    def load_agents(self):
        os.makedirs(os.path.dirname(self.data_path), exist_ok=True)
        if os.path.exists(self.data_path):
            try:
                with FileLock(self.lock_path):
                    with open(self.data_path, 'r') as file:
                        agents_data = json.load(file)
                        self.agents = [DeliveryAgent.from_dict(agent) for agent in agents_data]
            except Exception as e:
                print("Error loading agents:", e)
                self.initialize_default_agents()
        else:
            self.initialize_default_agents()

    def initialize_default_agents(self):
        default_agents = [
            DeliveryAgent(str(uuid.uuid4()), "John Doe", "555-1234"),
            DeliveryAgent(str(uuid.uuid4()), "Jane Smith", "555-5678"),
            DeliveryAgent(str(uuid.uuid4()), "Mike Johnson", "555-9012")
        ]
        self.agents = default_agents
        self.save_agents()

    def save_agents(self):
        os.makedirs(os.path.dirname(self.data_path), exist_ok=True)
        with FileLock(self.lock_path):
            with open(self.data_path, 'w') as file:
                json.dump([agent.to_dict() for agent in self.agents], file)

    def get_all_agents(self):
        self.load_agents()
        return self.agents

    def get_available_agents(self):
        return [agent for agent in self.agents if agent.status == DeliveryAgentStatus.AVAILABLE]

    def get_agent_by_id(self, agent_id: str):
        return next((agent for agent in self.agents if agent.id == agent_id), None)

    def add_agent(self, name: str, phone: str):
        new_agent = DeliveryAgent(str(uuid.uuid4()), name, phone)
        self.agents.append(new_agent)
        self.save_agents()
        return new_agent

    def assign_order_to_agent(self, agent_id: str, order_id: str):
        agent = self.get_agent_by_id(agent_id)
        if agent:
            agent.assign_order(order_id)
            self.save_agents()
            return True
        return False

    def complete_agent_order(self, agent_id: str):
        agent = self.get_agent_by_id(agent_id)
        if agent:
            agent.complete_order()
            self.save_agents()
            return True
        return False

class UserService:
    def __init__(self, data_path: str = "data/users.json"):
        self.data_path = data_path
        self.lock_path = data_path + ".lock"
        self.users = []
        self.current_user = None
        self.load_users()

    def load_users(self):
        os.makedirs(os.path.dirname(self.data_path), exist_ok=True)
        if os.path.exists(self.data_path):
            try:
                with FileLock(self.lock_path):
                    with open(self.data_path, 'r') as file:
                        users_data = json.load(file)
                        self.users = [User.from_dict(user) for user in users_data]
            except Exception as e:
                print("Error loading users:", e)
                self.initialize_default_users()
        else:
            self.initialize_default_users()

    def initialize_default_users(self):
        default_users = [
            User(str(uuid.uuid4()), "Admin User", "555-0000", "123 Admin St", True),
            User(str(uuid.uuid4()), "Customer One", "555-1111", "456 Customer Ave", False),
            User(str(uuid.uuid4()), "Customer Two", "555-2222", "789 Client Blvd", False)
        ]
        self.users = default_users
        self.save_users()

    def save_users(self):
        os.makedirs(os.path.dirname(self.data_path), exist_ok=True)
        with FileLock(self.lock_path):
            with open(self.data_path, 'w') as file:
                json.dump([user.to_dict() for user in self.users], file)

    def get_all_users(self):
        self.load_users()
        return self.users

    def get_user_by_id(self, user_id: str):
        return next((user for user in self.users if user.id == user_id), None)

    def register_user(self, name: str, phone: str, address: str, is_admin: bool = False):
        new_user = User(str(uuid.uuid4()), name, phone, address, is_admin)
        self.users.append(new_user)
        self.save_users()
        return new_user

    def login(self, user_id: str):
        user = self.get_user_by_id(user_id)
        if user:
            self.current_user = user
            return True
        return False

    def logout(self):
        self.current_user = None

    def get_current_user(self):
        return self.current_user

# ----------------------------
# Background Thread: Order Status Updater
# ----------------------------
def background_order_status_checker(order_service: OrderService):
    """Background thread to check and update orders past their estimated delivery time."""
    while True:
        time.sleep(60)  # Check every 60 seconds
        active_orders = order_service.get_active_orders()
        now = datetime.datetime.now()
        for order in active_orders:
            if order.estimated_delivery_time and now >= order.estimated_delivery_time:
                # Only update if the order isn't already marked delivered/completed
                if order.status not in [OrderStatus.DELIVERED, OrderStatus.COMPLETED]:
                    order.update_status(OrderStatus.DELIVERED)
                    order_service.save_orders()
                    # Notify the admin/user (print to console)
                    print(f"\n[Background Update] Order {order.id[:8]} marked as delivered automatically.")

# ----------------------------
# UI Views
# ----------------------------
class BaseView:
    def __init__(self, menu_service, order_service, delivery_agent_service, user_service):
        self.menu_service = menu_service
        self.order_service = order_service
        self.delivery_agent_service = delivery_agent_service
        self.user_service = user_service

    def clear_screen(self):
        os.system('cls' if os.name == 'nt' else 'clear')

    def print_header(self, title):
        self.clear_screen()
        print("=" * 50)
        print(f"{title:^50}")
        print("=" * 50)
        print()

    def print_menu_items(self, items):
        if not items:
            print("No items available.")
            return
        print(f"{'ID':<10} {'Name':<20} {'Price':<10} {'Category':<15}")
        print("-" * 55)
        for item in items:
            print(f"{item.id[:8]:<10} {item.name:<20} ${item.price:<9.2f} {item.category:<15}")

    def print_order_details(self, order):
        print(f"Order ID: {order.id[:8]}")
        print(f"Status: {order.status.value}")
        print(f"Type: {order.order_type.value}")
        if order.order_type == OrderType.HOME_DELIVERY:
            print(f"Delivery Address: {order.address}")
            if order.delivery_agent_id:
                agent = self.delivery_agent_service.get_agent_by_id(order.delivery_agent_id)
                if agent:
                    print(f"Delivery Agent: {agent.name} ({agent.phone})")
        print(f"Placed: {order.placed_time.strftime('%Y-%m-%d %H:%M:%S')}")
        if order.estimated_delivery_time:
            print(f"Estimated Delivery: {order.estimated_delivery_time.strftime('%Y-%m-%d %H:%M:%S')}")
            if order.status not in [OrderStatus.DELIVERED, OrderStatus.COMPLETED, OrderStatus.CANCELLED]:
                print(f"Time Remaining: {order.get_time_remaining()}")
        print("\nItems:")
        print(f"{'Name':<20} {'Quantity':<10} {'Price':<10} {'Total':<10}")
        print("-" * 50)
        total = 0
        for item in order.items:
            item_total = item.get_total_price()
            total += item_total
            print(f"{item.menu_item.name:<20} {item.quantity:<10} ${item.menu_item.price:<9.2f} ${item_total:<9.2f}")
        print("-" * 50)
        print(f"Total Amount: ${total:.2f}")

class LoginView(BaseView):
    def show(self):
        self.menu_service.load_menu()
        self.order_service.load_orders()
        self.delivery_agent_service.load_agents()
        self.user_service.load_users()
        while True:
            self.print_header("Food Delivery System - Login")
            print("1. Login")
            print("2. Register")
            print("0. Exit")
            choice = input("\nEnter your choice: ")
            if choice == "1":
                self.login()
            elif choice == "2":
                self.register()
            elif choice == "0":
                return None
            else:
                input("Invalid choice. Press Enter to continue...")

    def login(self):
        self.print_header("Login")
        users = self.user_service.get_all_users()
        if not users:
            print("No users found. Please register first.")
            input("Press Enter to continue...")
            return
        print("Available Users:")
        for i, user in enumerate(users, 1):
            print(f"{i}. {user.name} (ID: {user.id[:8]}), Admin: {user.is_admin}")
        try:
            user_idx = int(input("\nSelect user (number): ")) - 1
            if 0 <= user_idx < len(users):
                user = users[user_idx]
                if self.user_service.login(user.id):
                    print(f"Welcome, {user.name}!")
                    input("Press Enter to continue...")
                    if user.is_admin:
                        admin_view = AdminView(self.menu_service, self.order_service, self.delivery_agent_service, self.user_service)
                        return admin_view.show()
                    else:
                        customer_view = self.CustomerView(self.menu_service, self.order_service, self.delivery_agent_service, self.user_service)
                        return customer_view.show()
                else:
                    print("Login failed.")
            else:
                print("Invalid user selection.")
        except ValueError:
            print("Please enter a valid number.")
        input("Press Enter to continue...")
        return None

    def register(self):
        self.print_header("Register New User")
        name = input("Enter your name: ")
        phone = input("Enter your phone number: ")
        address = input("Enter your address: ")
        new_user = self.user_service.register_user(name, phone, address)
        print(f"User registered successfully! Your ID is: {new_user.id[:8]}")
        input("Press Enter to continue...")

    class CustomerView(BaseView):
        def show(self):
            self.menu_service.load_menu()
            self.order_service.load_orders()
            self.delivery_agent_service.load_agents()
            self.user_service.load_users()
            while True:
                user = self.user_service.get_current_user()
                if not user:
                    return LoginView(self.menu_service, self.order_service, self.delivery_agent_service, self.user_service)
                self.print_header(f"Customer Dashboard - {user.name}")
                print("1. View Menu")
                print("2. Place Order")
                print("3. View My Orders")
                print("4. Track Order")
                print("5. Logout")
                choice = input("\nEnter your choice: ")
                if choice == "1":
                    self.view_menu()
                elif choice == "2":
                    self.place_order()
                elif choice == "3":
                    self.view_my_orders()
                elif choice == "4":
                    self.track_order()
                elif choice == "5":
                    self.user_service.logout()
                    return LoginView(self.menu_service, self.order_service, self.delivery_agent_service, self.user_service)
                else:
                    input("Invalid choice. Press Enter to continue...")

        def view_menu(self):
            self.print_header("Menu")
            items = self.menu_service.get_all_items()
            self.print_menu_items(items)
            input("\nPress Enter to continue...")

        def place_order(self):
            self.print_header("Place Order")
            items = self.menu_service.get_all_items()
            if not items:
                print("No menu items available. Cannot place order.")
                input("Press Enter to continue...")
                return
            order_items = []
            order = None  # Initialize order variable
            while True:
                self.print_menu_items(items)
                print("\nCurrent order:")
                if not order_items:
                    print("No items added yet.")
                else:
                    for i, order_item in enumerate(order_items, 1):
                        print(f"{i}. {order_item.menu_item.name} x{order_item.quantity} - ${order_item.get_total_price():.2f}")
                    print(f"Total: ${sum(item.get_total_price() for item in order_items):.2f}")
                print("\n1. Add item to order")
                print("2. Remove item from order")
                print("3. Confirm order")
                print("0. Cancel")
                choice = input("\nEnter your choice: ")
                if choice == "1":
                    self.add_item_to_order(items, order_items)
                elif choice == "2":
                    self.remove_item_from_order(order_items)
                elif choice == "3":
                    if not order_items:
                        print("Cannot place empty order.")
                        input("Press Enter to continue...")
                        continue
                    user = self.user_service.get_current_user()
                    print("\nOrder Type:")
                    print("1. Home Delivery")
                    print("2. Takeaway")
                    order_type_choice = input("Enter your choice: ")
                    if order_type_choice == "1":
                        order_type = OrderType.HOME_DELIVERY
                        address = input(f"Delivery address [{user.address}]: ") or user.address
                    elif order_type_choice == "2":
                        order_type = OrderType.TAKEAWAY
                        address = None
                    else:
                        print("Invalid choice.")
                        input("Press Enter to continue...")
                        continue

                    # For Home Delivery, check if any delivery agents are available.
                    if order_type == OrderType.HOME_DELIVERY:
                        available_agents = self.delivery_agent_service.get_available_agents()
                        if not available_agents:
                            print("No available delivery agents. Please try again later.")
                            input("Press Enter to continue...")
                            return

                    # Create the order first
                    order = self.order_service.create_order(user.id, order_items, order_type, address)

                    # If Home Delivery, assign a delivery agent.
                    if order_type == OrderType.HOME_DELIVERY:
                        available_agents = self.delivery_agent_service.get_available_agents()
                        if available_agents:
                            agent = available_agents[0]  # Choose the first available agent.
                            # Assign the order to the agent in the order record.
                            self.order_service.assign_delivery_agent(order.id, agent.id)
                            # Update order status to indicate it's out for delivery.
                            self.order_service.update_order_status(order.id, OrderStatus.OUT_FOR_DELIVERY)
                            # Update the delivery agent object to reflect the assignment.
                            self.delivery_agent_service.assign_order_to_agent(agent.id, order.id)
                            print(f"Delivery agent {agent.name} has been assigned to your order.")
                        else:
                            # This branch should not be reached due to the earlier check.
                            print("Unexpected error: No available delivery agents at assignment time.")
                    print("\nOrder placed successfully!")
                    print(f"Order ID: {order.id[:8]}")
                    print(f"Estimated {'delivery' if order_type == OrderType.HOME_DELIVERY else 'pickup'} time: {order.estimated_delivery_time.strftime('%H:%M:%S')}")
                    input("Press Enter to continue...")
                    return
                elif choice == "0":
                    return
                else:
                    input("Invalid choice. Press Enter to continue...")

        def add_item_to_order(self, menu_items, order_items):
            try:
                item_idx = int(input("\nEnter item number (1, 2, etc.): ")) - 1
                if 0 <= item_idx < len(menu_items):
                    menu_item = menu_items[item_idx]
                    quantity = int(input(f"Enter quantity for {menu_item.name}: "))
                    if quantity <= 0:
                        print("Quantity must be positive.")
                        input("Press Enter to continue...")
                        return
                    existing_item = next((item for item in order_items if item.menu_item.id == menu_item.id), None)
                    if existing_item:
                        existing_item.quantity += quantity
                    else:
                        order_items.append(OrderItem(menu_item, quantity))
                    print(f"Added {quantity} x {menu_item.name} to order.")
                else:
                    print("Invalid item number.")
            except ValueError:
                print("Please enter a valid number.")
            input("Press Enter to continue...")

        def remove_item_from_order(self, order_items):
            if not order_items:
                print("No items in order.")
                input("Press Enter to continue...")
                return
            try:
                item_idx = int(input("\nEnter item number to remove: ")) - 1
                if 0 <= item_idx < len(order_items):
                    removed_item = order_items.pop(item_idx)
                    print(f"Removed {removed_item.menu_item.name} from order.")
                else:
                    print("Invalid item number.")
            except ValueError:
                print("Please enter a valid number.")
            input("Press Enter to continue...")

        def view_my_orders(self):
            self.print_header("My Orders")
            user = self.user_service.get_current_user()
            orders = self.order_service.get_orders_by_customer(user.id)
            if not orders:
                print("You have no orders.")
                input("Press Enter to continue...")
                return
            print(f"You have {len(orders)} orders:")
            for i, order in enumerate(orders, 1):
                print(f"{i}. Order ID: {order.id[:8]} - Status: {order.status.value}")
                print(f"   Placed: {order.placed_time.strftime('%Y-%m-%d %H:%M:%S')}")
                print(f"   Total: ${order.get_total_amount():.2f}")
                print()
            try:
                order_idx = int(input("\nEnter order number to view details (0 to go back): ")) - 1
                if order_idx == -1:
                    return
                if 0 <= order_idx < len(orders):
                    self.view_order_details(orders[order_idx])
                else:
                    print("Invalid order number.")
                input("Press Enter to continue...")
            except ValueError:
                print("Please enter a valid number.")
            input("Press Enter to continue...")

        def view_order_details(self, order):
            self.print_header(f"Order Details - {order.id[:8]}")
            self.print_order_details(order)
            input("\nPress Enter to continue...")

        def track_order(self):
            self.print_header("Track Order")
            user = self.user_service.get_current_user()
            active_orders = [order for order in self.order_service.get_orders_by_customer(user.id)
                             if order.status not in [OrderStatus.DELIVERED, OrderStatus.COMPLETED, OrderStatus.CANCELLED]]
            if not active_orders:
                print("You have no active orders to track.")
                input("Press Enter to continue...")
                return
            print("Your active orders:")
            for i, order in enumerate(active_orders, 1):
                print(f"{i}. Order ID: {order.id[:8]} - Status: {order.status.value}")
                if order.estimated_delivery_time:
                    print(f"   Expected: {order.estimated_delivery_time.strftime('%H:%M:%S')} ({order.get_time_remaining()})")
                print()
            try:
                order_idx = int(input("\nEnter order number to view details (0 to go back): ")) - 1
                if order_idx == -1:
                    return
                if 0 <= order_idx < len(active_orders):
                    self.view_order_details(active_orders[order_idx])
                else:
                    print("Invalid order number.")
                    input("Press Enter to continue...")
            except ValueError:
                print("Please enter a valid number.")
                input("Press Enter to continue...")

class AdminView(BaseView):
     def show(self):
        self.menu_service.load_menu()
        self.order_service.load_orders()
        self.delivery_agent_service.load_agents()
        self.user_service.load_users()
        while True:
            user = self.user_service.get_current_user()
            if not user or not user.is_admin:
                return LoginView(self.menu_service, self.order_service, self.delivery_agent_service, self.user_service)
            self.print_header(f"Admin Dashboard - {user.name}")
            print("1. Manage Menu")
            print("2. View All Orders")
            print("3. Manage Delivery Agents")
            print("4. Update Order Status")
            print("5. Assign Delivery Agent")
            print("6. Restaurant POV")
            print("7. Logout")
            choice = input("\nEnter your choice: ")
            if choice == "1":
                self.manage_menu()
            elif choice == "2":
                self.view_all_orders()
            elif choice == "3":
                self.manage_delivery_agents()
            elif choice == "4":
                self.update_order_status()
            elif choice == "5":
                self.assign_delivery_agent()
            elif choice == "6":
                self.view_restaurant_pov()
            elif choice == "7":
                self.user_service.logout()
                return LoginView(self.menu_service, self.order_service, self.delivery_agent_service, self.user_service)
            else:
                input("Invalid choice. Press Enter to continue...")


     def add_delivery_agent(self):
        self.print_header("Add Delivery Agent")
        name = input("Enter agent name: ")
        phone = input("Enter agent phone: ")
        agent = self.delivery_agent_service.add_agent(name, phone)
        print(f"\nDelivery agent '{agent.name}' added successfully!")
        input("Press Enter to continue...")

     def complete_agent_order(self):
        self.print_header("Complete Agent Order")
        busy_agents = [agent for agent in self.delivery_agent_service.get_all_agents()
                       if agent.status == DeliveryAgentStatus.BUSY]
        if not busy_agents:
            print("No agents currently on delivery.")
            input("Press Enter to continue...")
            return
        print("Agents on delivery:")
        for i, agent in enumerate(busy_agents, 1):
            order = self.order_service.get_order_by_id(agent.current_order_id)
            order_info = f"Order {agent.current_order_id[:8]}" if order else "Unknown Order"
            print(f"{i}. {agent.name} - {order_info}")
        try:
            agent_idx = int(input("\nEnter agent number to mark order as complete: ")) - 1
            if 0 <= agent_idx < len(busy_agents):
                agent = busy_agents[agent_idx]
                if agent.current_order_id:
                    order = self.order_service.get_order_by_id(agent.current_order_id)
                    if order:
                        self.order_service.update_order_status(order.id, OrderStatus.DELIVERED)
                        print(f"Order {order.id[:8]} marked as delivered.")
                if self.delivery_agent_service.complete_agent_order(agent.id):
                    print(f"Agent {agent.name}'s order marked as complete.")
                else:
                    print("Failed to update agent status.")
            else:
                print("Invalid agent number.")
        except ValueError:
            print("Please enter a valid number.")
        input("Press Enter to continue...")

     def remove_delivery_agent(self):
        self.print_header("Remove Delivery Agent")
        agents = self.delivery_agent_service.get_all_agents()
        if not agents:
            print("No delivery agents to remove.")
            input("Press Enter to continue...")
            return
        print("Select a delivery agent to remove:")
        for i, agent in enumerate(agents, 1):
            print(f"{i}. {agent.name} ({agent.id[:8]})")
        try:
            agent_idx = int(input("\nEnter agent number: ")) - 1
            if 0 <= agent_idx < len(agents):
                agent = agents[agent_idx]
                confirm = input(f"Are you sure you want to remove {agent.name}? (y/n): ").lower()
                if confirm == 'y':
                    if self.delivery_agent_service.remove_agent(agent.id):
                        print("Agent removed successfully.")
                    else:
                        print("Failed to remove agent.")
                else:
                    print("Operation cancelled.")
            else:
                print("Invalid selection.")
        except ValueError:
            print("Please enter a valid number.")
        input("Press Enter to continue...")

     def manage_menu(self):
        while True:
            self.print_header("Manage Menu")
            items = self.menu_service.get_all_items()
            self.print_menu_items(items)
            print("\n1. Add Item")
            print("2. Update Item")
            print("3. Remove Item")
            print("0. Back")
            choice = input("\nEnter your choice: ")
            if choice == "1":
                self.add_menu_item()
            elif choice == "2":
                self.update_menu_item()
            elif choice == "3":
                self.remove_menu_item()
            elif choice == "0":
                return
            else:
                input("Invalid choice. Press Enter to continue...")

     def add_menu_item(self):
        self.print_header("Add Menu Item")
        name = input("Enter item name: ")
        description = input("Enter item description: ")
        try:
            price = float(input("Enter item price: $"))
            if price <= 0:
                print("Price must be positive.")
                input("Press Enter to continue...")
                return
        except ValueError:
            print("Invalid price format.")
            input("Press Enter to continue...")
            return
        category = input("Enter item category: ")
        item = self.menu_service.add_item(name, description, price, category)
        print(f"\nItem '{item.name}' added successfully!")
        input("Press Enter to continue...")

     def update_menu_item(self):
        self.print_header("Update Menu Item")
        items = self.menu_service.get_all_items()
        self.print_menu_items(items)
        if not items:
            input("Press Enter to continue...")
            return
        try:
            item_idx = int(input("\nEnter item number to update: ")) - 1
            if 0 <= item_idx < len(items):
                item = items[item_idx]
                print(f"\nUpdating item: {item.name}")
                name = input(f"Enter new name [{item.name}]: ") or item.name
                description = input(f"Enter new description [{item.description}]: ") or item.description
                try:
                    price_input = input(f"Enter new price [${item.price:.2f}]: ")
                    price = float(price_input) if price_input else item.price
                    if price <= 0:
                        print("Price must be positive.")
                        input("Press Enter to continue...")
                        return
                except ValueError:
                    print("Invalid price format.")
                    input("Press Enter to continue...")
                    return
                category = input(f"Enter new category [{item.category}]: ") or item.category
                if self.menu_service.update_item(item.id, name, description, price, category):
                    print("\nItem updated successfully!")
                else:
                    print("\nFailed to update item.")
            else:
                print("Invalid item number.")
        except ValueError:
            print("Please enter a valid number.")
        input("Press Enter to continue...")

     def remove_menu_item(self):
        self.print_header("Remove Menu Item")
        items = self.menu_service.get_all_items()
        self.print_menu_items(items)
        if not items:
            input("Press Enter to continue...")
            return
        try:
            item_idx = int(input("\nEnter item number to remove: ")) - 1
            if 0 <= item_idx < len(items):
                item = items[item_idx]
                confirm = input(f"Are you sure you want to remove '{item.name}'? (y/n): ").lower()
                if confirm == 'y':
                    if self.menu_service.remove_item(item.id):
                        print("\nItem removed successfully!")
                    else:
                        print("\nFailed to remove item.")
            else:
                print("Invalid item number.")
        except ValueError:
            print("Please enter a valid number.")
        input("Press Enter to continue...")

     def view_all_orders(self):
        self.print_header("All Orders")
        orders = self.order_service.get_all_orders()
        if not orders:
            print("No orders found.")
            input("Press Enter to continue...")
            return
        print(f"Total orders: {len(orders)}")
        print(f"{'ID':<10} {'Customer':<15} {'Status':<15} {'Type':<15} {'Total':<10} {'Placed Time':<20}")
        print("-" * 85)
        for order in orders:
            customer = self.user_service.get_user_by_id(order.customer_id)
            customer_name = customer.name if customer else "Unknown"
            print(f"{order.id[:8]:<10} {customer_name[:15]:<15} {order.status.value:<15} {order.order_type.value:<15} ${order.get_total_amount():<9.2f} {order.placed_time.strftime('%Y-%m-%d %H:%M')}")
        try:
            order_id = input("\nEnter order ID to view details (or press Enter to go back): ")
            if order_id:
                order = next((o for o in orders if o.id.startswith(order_id)), None)
                if order:
                    self.view_order_details(order)
                else:
                    print("Order not found.")
                    input("Press Enter to continue...")
        except ValueError:
            print("Invalid input.")
            input("Press Enter to continue...")

     def view_order_details(self, order):
        self.print_header(f"Order Details - {order.id[:8]}")
        customer = self.user_service.get_user_by_id(order.customer_id)
        if customer:
            print(f"Customer: {customer.name}")
            print(f"Phone: {customer.phone}")
        self.print_order_details(order)
        input("\nPress Enter to continue...")

     def manage_delivery_agents(self):
        # Refresh the delivery agents data from file.
        self.delivery_agent_service.load_agents()
        self.print_header("Manage Delivery Agents")
        agents = self.delivery_agent_service.get_all_agents()
        if not agents:
            print("No delivery agents found.")
        else:
            print(f"{'ID':<10} {'Name':<20} {'Phone':<15} {'Status':<10} {'Current Order':<15}")
            print("-" * 70)
            for agent in agents:
                current_order = agent.current_order_id[:8] if agent.current_order_id else "None"
                print(f"{agent.id[:8]:<10} {agent.name:<20} {agent.phone:<15} {agent.status.value:<10} {current_order:<15}")
        print("\n1. Add Delivery Agent")
        print("2. Complete Agent Order")
        print("0. Back")
        choice = input("\nEnter your choice: ")
        if choice == "1":
            self.add_delivery_agent()
        elif choice == "2":
            self.complete_agent_order()
        elif choice == "0":
            return
        else:
            input("Invalid choice. Press Enter to continue...")



     def add_delivery_agent(self):
        self.print_header("Add Delivery Agent")
        name = input("Enter agent name: ")
        phone = input("Enter agent phone: ")
        agent = self.delivery_agent_service.add_agent(name, phone)
        print(f"\nDelivery agent '{agent.name}' added successfully!")
        input("Press Enter to continue...")

     def complete_agent_order(self):
        self.print_header("Complete Agent Order")
        busy_agents = [agent for agent in self.delivery_agent_service.get_all_agents()
                       if agent.status == DeliveryAgentStatus.BUSY]
        if not busy_agents:
            print("No agents currently on delivery.")
            input("Press Enter to continue...")
            return
        print("Agents on delivery:")
        for i, agent in enumerate(busy_agents, 1):
            order = self.order_service.get_order_by_id(agent.current_order_id)
            order_info = f"Order {agent.current_order_id[:8]}" if order else "Unknown Order"
            print(f"{i}. {agent.name} - {order_info}")
        try:
            agent_idx = int(input("\nEnter agent number to mark order as complete: ")) - 1
            if 0 <= agent_idx < len(busy_agents):
                agent = busy_agents[agent_idx]
                if agent.current_order_id:
                    order = self.order_service.get_order_by_id(agent.current_order_id)
                    if order:
                        self.order_service.update_order_status(order.id, OrderStatus.DELIVERED)
                        print(f"Order {order.id[:8]} marked as delivered.")
                if self.delivery_agent_service.complete_agent_order(agent.id):
                    print(f"Agent {agent.name}'s order marked as complete.")
                else:
                    print("Failed to update agent status.")
            else:
                print("Invalid agent number.")
        except ValueError:
            print("Please enter a valid number.")
        input("Press Enter to continue...")

     def update_order_status(self):
        self.print_header("Update Order Status")
        active_orders = self.order_service.get_active_orders()
        if not active_orders:
            print("No active orders found.")
            input("Press Enter to continue...")
            return
        print("Active orders:")
        for i, order in enumerate(active_orders, 1):
            customer = self.user_service.get_user_by_id(order.customer_id)
            customer_name = customer.name if customer else "Unknown"
            print(f"{i}. Order ID: {order.id[:8]} - Customer: {customer_name}")
            print(f"   Status: {order.status.value} - Type: {order.order_type.value}")
            print(f"   Placed: {order.placed_time.strftime('%Y-%m-%d %H:%M:%S')}")
            print()
        try:
            order_idx = int(input("\nEnter order number to update status: ")) - 1
            if 0 <= order_idx < len(active_orders):
                order = active_orders[order_idx]
                print("\nAvailable statuses:")
                statuses = list(OrderStatus)
                for i, status in enumerate(statuses, 1):
                    print(f"{i}. {status.value}")
                status_idx = int(input("\nSelect new status: ")) - 1
                if 0 <= status_idx < len(statuses):
                    new_status = statuses[status_idx]
                    if self.order_service.update_order_status(order.id, new_status):
                        print(f"Order status updated to: {new_status.value}")
                    else:
                        print("Failed to update order status.")
                else:
                    print("Invalid status selection.")
            else:
                print("Invalid order number.")
        except ValueError:
            print("Please enter a valid number.")
        input("Press Enter to continue...")

     def assign_delivery_agent(self):
        self.print_header("Assign Delivery Agent")
        delivery_orders = [order for order in self.order_service.get_active_orders()
                           if order.order_type == OrderType.HOME_DELIVERY and not order.delivery_agent_id]
        if not delivery_orders:
            print("No unassigned delivery orders found.")
            input("Press Enter to continue...")
            return
        print("Unassigned delivery orders:")
        for i, order in enumerate(delivery_orders, 1):
            customer = self.user_service.get_user_by_id(order.customer_id)
            customer_name = customer.name if customer else "Unknown"
            print(f"{i}. Order ID: {order.id[:8]} - Customer: {customer_name}")
            print(f"   Address: {order.address}")
            print(f"   Status: {order.status.value}")
            print()
        try:
            order_idx = int(input("\nEnter order number to assign agent: ")) - 1
            if 0 <= order_idx < len(delivery_orders):
                order = delivery_orders[order_idx]
                available_agents = self.delivery_agent_service.get_available_agents()
                if not available_agents:
                    print("No available delivery agents.")
                    input("Press Enter to continue...")
                    return
                print("\nAvailable agents:")
                for i, agent in enumerate(available_agents, 1):
                    print(f"{i}. {agent.name} - {agent.phone}")
                agent_idx = int(input("\nSelect agent to assign: ")) - 1
                if 0 <= agent_idx < len(available_agents):
                    agent = available_agents[agent_idx]
                    if self.order_service.assign_delivery_agent(order.id, agent.id):
                        self.order_service.update_order_status(order.id, OrderStatus.OUT_FOR_DELIVERY)
                        self.delivery_agent_service.assign_order_to_agent(agent.id, order.id)
                        print(f"Agent {agent.name} assigned to order {order.id[:8]}")
                    else:
                        print("Failed to assign delivery agent.")
                else:
                    print("Invalid agent selection.")
            else:
                print("Invalid order number.")
        except ValueError:
            print("Please enter a valid number.")
        input("Press Enter to continue...")

     def view_restaurant_pov(self):
        self.print_header("Restaurant POV")
        orders = self.order_service.get_all_orders()
        total_orders = len(orders)
        total_revenue = sum(order.get_total_amount() for order in orders if order.status in [OrderStatus.DELIVERED, OrderStatus.COMPLETED])
        home_delivery_orders = len([order for order in orders if order.order_type == OrderType.HOME_DELIVERY])
        takeaway_orders = len([order for order in orders if order.order_type == OrderType.TAKEAWAY])
        print(f"Total Orders: {total_orders}")
        print(f"Total Revenue (from completed/delivered orders): ${total_revenue:.2f}")
        print(f"Home Delivery Orders: {home_delivery_orders}")
        print(f"Takeaway Orders: {takeaway_orders}")
        input("\nPress Enter to continue...")

# ----------------------------
# Main Application and Instance
# ----------------------------
def main():
    menu_service = MenuService()
    delivery_agent_service = DeliveryAgentService()
    user_service = UserService()
    order_service = OrderService(menu_service)

    # Start background thread for auto-updating order status
    updater_thread = threading.Thread(target=background_order_status_checker, args=(order_service,), daemon=True)
    updater_thread.start()

    current_view = LoginView(menu_service, order_service, delivery_agent_service, user_service)
    while current_view:
        next_view = current_view.show()
        if next_view:
            current_view = next_view
        else:
            if isinstance(current_view, LoginView):
                break
            else:
                current_view = LoginView(menu_service, order_service, delivery_agent_service, user_service)
    print("Thank you for using the Food Delivery System!")

class ApplicationInstance:
    _instance = None
    _lock = threading.Lock()

    @classmethod
    def get_instance(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = cls()
        return cls._instance

    def run(self):
        main()

if __name__ == "__main__":
    app = ApplicationInstance.get_instance()
    app.run()