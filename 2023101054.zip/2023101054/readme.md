# Food Delivery System Classes Documentation

## Utility Classes

### FileLock
- Thread-safe file locking mechanism
- Ensures data consistency during concurrent operations
- Uses system-specific file locking (fcntl for Unix)

## Enums

### OrderType
- Defines order delivery methods:
  - HOME_DELIVERY
  - TAKEAWAY

### OrderStatus
- Tracks order progress:
  - PLACED
  - PREPARING
  - READY_FOR_PICKUP
  - OUT_FOR_DELIVERY
  - DELIVERED
  - COMPLETED
  - CANCELLED

### DeliveryAgentStatus
- Tracks delivery agent availability:
  - AVAILABLE
  - BUSY
  - OFFLINE

## Core Model Classes

### MenuItem
- Represents food items in the menu
- Properties:
  - id: Unique identifier
  - name: Item name
  - description: Item description
  - price: Item price
  - category: Item category
- Includes validation for positive prices
- Methods for dictionary conversion

### OrderItem
- Represents items in an order
- Properties:
  - menu_item: Reference to MenuItem
  - quantity: Number of items ordered
- Calculates total price for items

### Order
- Manages order information
- Properties:
  - id: Unique order identifier
  - customer_id: Customer reference
  - items: List of OrderItems
  - order_type: Type of delivery
  - address: Delivery address
  - status: Current order status
  - delivery_agent_id: Assigned agent
- Tracks timing information
- Calculates total amounts

### DeliveryAgent
- Manages delivery personnel
- Properties:
  - id: Unique identifier
  - name: Agent name
  - phone: Contact number
  - status: Current availability
  - current_order_id: Active order
- Methods for order assignment

### User
- Manages user accounts
- Properties:
  - id: Unique identifier
  - name: User name
  - phone: Contact number
  - address: Delivery address
  - is_admin: Administrative privileges

## Service Classes

### MenuService
- Manages menu items
- Features:
  - CRUD operations for menu items
  - Menu persistence
  - Category management

### OrderService
- Handles order processing
- Features:
  - Order creation and tracking
  - Status updates
  - Delivery assignments
  - Order history

### DeliveryAgentService
- Manages delivery personnel
- Features:
  - Agent assignments
  - Availability tracking
  - Order completion
  - Agent roster management

### UserService
- Handles user accounts
- Features:
  - User registration
  - Authentication
  - Profile management
  - Admin privileges

## View Classes

### BaseView
- Base class for UI views
- Common UI utilities
- Screen management

### LoginView
- Handles authentication
- User registration
- Access control

### CustomerView
- Customer interface
- Order placement
- Order tracking
- Menu browsing

### AdminView
- Administrative interface
- Menu management
- Order oversight
- Agent management
- System monitoring

## Application Management

### ApplicationInstance
- Singleton pattern implementation
- Main application entry point
- Thread management
- System initialization

## Background Processes

### Background Order Status Checker
- Automatic order status updates
- Delivery time monitoring
- System notifications# Core Model Tests

## test_menu_item_validation()
- Tests validation of MenuItem creation
- Ensures prices cannot be negative
- Critical for data integrity

## test_order_item_calculations()
- Verifies OrderItem price calculations
- Ensures correct multiplication of item price by quantity

## test_menu_item_availability()
- Checks if menu items are available
- Ensures accurate stock levels
- Important for inventory management

## test_order_time_calculations()
- Tests order delivery time estimations
- Verifies proper datetime handling
- Essential for customer service

# Service Tests

## Menu Service Tests

### test_menu_service_initialization()
- Verifies proper loading of menu items

### test_menu_service_crud()
- Tests Create, Read, Update, Delete operations

### test_menu_service_categories()
- Validates menu category organization

## Order Service Tests

### test_order_service_validation()
- Ensures orders meet minimum requirements

### test_order_status_flow()
- Validates order status transitions

### test_order_batching()
- Tests batch processing capabilities

# Delivery Agent Tests

## test_delivery_agent_availability()
- Tracks agent status changes

## test_delivery_routing()
- Tests delivery assignment logic

# Integration Tests

## test_integration()
- Tests interaction between all services
- Simulates complete order flow
- Verifies system components work together

## test_concurrent_order_processing()
- Tests system under concurrent load
- Verifies thread safety
- Important for production reliability

# Advanced Feature Tests

## test_menu_item_variations()
- Tests menu item customization options
- Verifies price variations
- Important for menu flexibility

## test_system_load()
- Performance testing under heavy load
- Measures system responsiveness
- Critical for scalability assessment

# Running the Tests

To run the program:
```bash
python3 FoodDelivery.py
```

To run the test suite:
```bash
python3 -m unittest test_FoodDelivery.py
```





# Dollmart E-Market System

A command-line e-commerce system with user management, product catalog, shopping cart, and order tracking features.

## Core Classes

### Enums
- **UserType**: Defines customer types (individual/retail)
- **OrderStatus**: Tracks order states (placed/processing/shipped/delivered/cancelled)
- **DeliveryMethod**: Specifies delivery options (standard/express)

### User Classes
- **User (Abstract)**: Base class for all user types
  - Stores basic user info (name, email, address, etc.)
  - Manages shopping cart and order history
  - Abstract method for price calculations

- **AdminUser**: Administrator user with special privileges
  - Product management
  - Order oversight
  - No price modifications

- **IndividualCustomer**: Regular retail customer
  - Loyalty points system
  - Points-based discounts
  - Standard pricing

- **RetailCustomer**: Business customer
  - Requires business license
  - Automatic bulk discounts
  - Special pricing rules

### Product Management
- **Product**: Represents store items
  - Basic product details
  - Inventory tracking
  - Price management

### Order System
- **Order**: Handles purchase transactions
  - Tracks items and quantities
  - Manages delivery status
  - Generates tracking info
  - Auto-updates status

### Coupon System
- **Coupon**: Discount vouchers
  - Validation rules
  - Expiry tracking
  - Minimum purchase requirements

### Manager Classes
- **DataManager**: Handles file I/O operations
  - JSON data persistence
  - File system management
  - Data validation

- **UserManager**: User-related operations
  - Registration/login
  - Profile updates
  - Cart management

- **ProductManager**: Product catalog operations
  - Inventory management
  - Product search
  - Category management

- **OrderManager**: Order processing
  - Order placement
  - Status tracking
  - Delivery management

- **CouponManager**: Coupon operations
  - Coupon generation
  - Validation
  - Usage tracking

### Interface
- **DollmartCLI**: Main interface class
  - User interaction
  - Menu system
  - Command processing
  - Session management

## Key Features
- User authentication and authorization
- Product browsing and search
- Shopping cart management
- Order processing and tracking
- Loyalty points system
- Coupon management
- Real-time order status updates
- Different user types with specific privileges
- Automated order status progression

# Test Suite Documentation

This document explains the test suite (`test.py`) for the Dollmart E-Market system, with importance ratings based on core functionality.

## Test Environment Setup

The test suite uses pytest and sets up an isolated test environment:
- Creates a temporary `test_data` directory for test data
- Redirects all data file paths to this test directory
- Automatically cleans up test data after each test

## Test Categories

### 1. User Management Tests (`TestUserManager`) - Critical
- **Registration Tests**
  - `test_register_individual_customer`: (Critical) Verifies individual customer registration with loyalty points initialization
  - `test_register_retail_customer`: (Critical) Tests retail customer registration with business license validation
  - `test_register_duplicate_email`: (Critical) Ensures email uniqueness across the system

- **Login Tests**
  - `test_login_success`: (High) Validates user authentication and session creation
  - `test_admin_login`: (Critical) Verifies admin privileges and special access
  - `test_login_invalid_credentials`: (High) Tests security against unauthorized access

### 2. Product Management Tests (`TestProductManager`) - High
- **Product Operations**
  - `test_add_product`: (High) Validates product creation with UUID generation
  - `test_search_products`: (Medium) Tests product search across name and description
  - `test_search_products_case_insensitive`: (Low) Ensures user-friendly search functionality

- **Stock Management**
  - `test_update_product_stock`: (Critical) Verifies inventory tracking accuracy
  - `test_update_product_stock_negative`: (Critical) Tests prevention of invalid stock states

### 3. Order Management Tests (`TestOrderManager`) - Critical
- **Order Processing**
  - `test_place_order`: (Critical) Validates complete order flow including:
    - Stock verification
    - Price calculation
    - Loyalty points for individual customers
    - Retail customer discounts
  - `test_get_user_orders`: (High) Tests order history and tracking
  - `test_place_order_empty_cart`: (Medium) Validates cart state checking
  - `test_place_order_insufficient_stock`: (Critical) Ensures inventory integrity
  - `test_order_status_tracking`: (High) Verifies automatic order status progression through:
    - PLACED → PROCESSING (30s)
    - PROCESSING → SHIPPED (60s)
    - SHIPPED → DELIVERED (90s)

### 4. Data Management Tests (`TestDataManager`) - High
- **Data Persistence**
  - `test_load_nonexistent_file`: (High) Verifies system resilience with missing data
  - `test_save_and_load_data`: (Critical) Tests data integrity across operations

## Running Tests


To run the program:
```bash
python3 Dollmart.py
```

To run the test suite:
```bash
python3 -v pytest test_Dollmart.py
```

# GOBBLET.JR

Overview

Gobblet Gobblers is a strategic board game where two players (Red and Yellow) take turns placing or moving pieces on a 3x3 grid. The goal is to align three pieces of the same color in a row, column, or diagonal. Larger pieces can "gobble" smaller pieces, adding a layer of strategy to the game.

This implementation uses Pygame to provide a graphical interface for the game.
Features

    Interactive Gameplay: Players take turns clicking on the board or their reserve pieces to place or move pieces.

    Piece Hierarchy: Larger pieces can "gobble" smaller pieces.

    Win Condition Detection: Automatically detects when a player wins by aligning three pieces in a row, column, or diagonal.

    Graphical Interface: Rendered using Pygame with a clean and intuitive design.

How to Play

    Starting the Game:

        The game starts with the Red player's turn.

        Each player has a set of pieces in three sizes: large, medium, and small.

    Placing Pieces:

        Click on a piece from your reserve (left panel) to select it.

        Click on an empty cell or a cell with a smaller piece to place your piece.

    Moving Pieces:

        Click on a piece on the board to select it.

        Click on another cell to move the selected piece (if the move is valid).

    Winning the Game:

        The first player to align three pieces of their color in a row, column, or diagonal wins the game.

Controls

    Mouse: Use the mouse to select pieces and make moves.

    Quit: Close the game window to exit.

Code Structure

    Piece Class: Represents a game piece with a color and size.

    GobbletGobblers Class: Manages the game state, rendering, and user input.

    draw_board(): Renders the game board and pieces.

    handle_click(): Handles mouse click events for selecting and moving pieces.

    check_win(): Checks if a player has won the game.


# Food Delivery System Specifications

## System Requirements

### Hardware Requirements
- Computer system with minimum 4GB RAM
- Storage space: 1GB minimum
- Internet connectivity
- Printer (optional, for receipts)

### Software Requirements
- Python 3.7 or higher
- Operating System: Windows/Linux/MacOS
- File system access permissions
- JSON support for data storage

## Functional Requirements

1. User Management
   - Support multiple user roles (Admin, Customer)
   - User registration and login
   - Store user profiles and preferences
   - Maintain delivery addresses

2. Menu Management
   - CRUD operations for menu items
   - Categorize menu items
   - Price management
   - Item availability status

3. Order Processing
   - Shopping cart functionality
   - Multiple order types (Delivery/Takeaway)
   - Real-time order tracking
   - Estimated delivery time calculation

4. Delivery Management
   - Delivery agent assignment
   - Track delivery agent status
   - Route optimization
   - Order status updates

5. Payment Processing
   - Calculate order totals
   - Apply taxes and delivery charges
   - Track payment status

## Non-Functional Requirements

1. Performance
   - Order processing time < 3 seconds
   - Maximum system response time < 2 seconds
   - Support for concurrent users

2. Security
   - Secure file-based data storage
   - User authentication
   - Data integrity checks

3. Reliability
   - System availability > 99%
   - Data backup and recovery
   - Transaction consistency

4. Scalability
   - Support for growing menu items
   - Handle increasing user base
   - Extensible architecture

## Use Cases

### 1. Place Order
Main Flow:
1. Customer logs into system
2. Views menu items
3. Adds items to cart
4. Selects order type (Delivery/Takeaway)
5. Confirms delivery address
6. Reviews order
7. Places order
8. Receives order confirmation

Alternate Flows:
1a. Login fails
   - System shows error message
   - Returns to login screen

2a. Menu is empty
   - System shows "No items available"
   - Returns to main menu

3a. Invalid quantity
   - System shows error message
   - Returns to cart

4a. Delivery unavailable
   - System suggests takeaway
   - Returns to order type selection

5a. Invalid address
   - System prompts for correct address
   - Returns to address input

### 2. Manage Menu (Admin)
Main Flow:
1. Admin logs in
2. Selects menu management
3. Views current menu
4. Adds/Updates/Removes items
5. Saves changes
6. System confirms changes

Alternate Flows:
1a. Invalid admin credentials
   - System shows access denied
   - Returns to login

4a. Invalid price input
   - System shows error message
   - Returns to item edit form

5a. Save operation fails
   - System shows error message
   - Keeps current state
   - Retry option provided

### 3. Manage Delivery Agents
Main Flow:
1. Admin assigns orders to agents
2. Updates agent status
3. Tracks deliveries
4. Marks orders as delivered
5. Updates agent availability

Alternate Flows:
1a. No available agents
   - System shows warning
   - Holds order in queue
   - Notifies admin

3a. Agent offline
   - System reassigns order
   - Notifies admin
   - Updates order status

4a. Delivery issues
   - System logs problem
   - Notifies admin
   - Updates customer

### 4. Track Order
Main Flow:
1. Customer views order status
2. Checks estimated delivery time
3. Views delivery agent details
4. Receives updates
5. Confirms delivery

Alternate Flows:
1a. Order not found
   - System shows error
   - Provides order ID verification

2a. Delivery delayed
   - System updates ETA
   - Notifies customer
   - Provides reason

3a. Agent reassignment
   - System updates agent details
   - Notifies customer
   - Updates delivery time

### 5. Restaurant Operations
Main Flow:
1. View incoming orders
2. Update order status
3. Manage food preparation
4. Track delivery queue
5. View daily statistics

Alternate Flows:
1a. System overload
   - Temporary order pause
   - Notify customers
   - Show wait time

3a. Item unavailable
   - Update menu
   - Notify affected orders
   - Offer alternatives

5a. Report generation fails
   - Show cached data
   - Retry generation
   - Manual calculation option
