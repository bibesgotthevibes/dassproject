# pylint: disable=import-error, too-few-public-methods, too-many-instance-attributes, too-many-locals, too-many-return-statements, too-many-branches, too-many-statements
"""
Gobblet Gobblers Game Implementation

This module implements the Gobblet Gobblers game using the Pygame library. 
Gobblet Gobblers is a strategic board game where two players (red and yellow) 
take turns placing or moving pieces on a 3x3 grid. The goal is to align three 
pieces of the same color in a row, column, or diagonal. Larger pieces can 
"gobble" smaller pieces, adding a layer of strategy to the game.

The game features:
- A 3x3 board with stacks of pieces.
- Two players, each with a set of pieces in three sizes: large, medium, and small.
- A graphical interface rendered using Pygame.
- Win condition detection for rows, columns, and diagonals.

Classes:
    Piece: Represents a game piece with a color and size.
    GobbletGobblers: Manages the game state, rendering, and user input.

Usage:
    Run this script to start the game. Players take turns clicking on the board
    or their reserve pieces to place or move pieces. The game ends when a player
    aligns three pieces of their color in a row, column, or diagonal.
"""

import pygame

# Define size hierarchy
size_order = {'large': 3, 'medium': 2, 'small': 1}

class Piece:
    """
    Represents a game piece in Gobblet Gobblers.

    Attributes:
        color (str): The color of the piece, either 'red' or 'yellow'.
        size (str): The size of the piece, either 'large', 'medium', or 'small'.
    """
    def __init__(self, color, size):
        self.color = color
        self.size = size

    def __str__(self):
        return f"{self.color} {self.size} piece"

class GobbletGobblers:
    """
    Represents the Gobblet Gobblers game.

    This class manages the game state, including the board, pieces, and player turns.
    It also handles rendering the game using Pygame and processing user input.

    Attributes:
        red_pieces (dict): A dictionary tracking the number of available red pieces by size.
        yellow_pieces (dict): A dictionary tracking the number of available yellow pieces by size.
        current_player (str): The current player's color, either 'red' or 'yellow'.
        selected_piece (Piece or None): The currently selected piece for moving.
        game_over (bool): Indicates whether the game has ended.
        winner (str or None): The color of the winning player, if the game is over.
        width (int): The width of the game window.
        height (int): The height of the game window.
        screen (pygame.Surface): The Pygame surface representing the game window.
        cell_size (int): The size of each cell on the board.
        board_x (int): The x-coordinate of the top-left corner of the board.
        board_y (int): The y-coordinate of the top-left corner of the board.
        panel_x (int): The x-coordinate of the top-left corner of the player panel.
        panel_y (int): The y-coordinate of the top-left corner of the player panel.
        panel_width (int): The width of the player panel.
        colors (dict): A dictionary mapping color names to RGB tuples.
    """
    def __init__(self):
        self.board = [[[] for _ in range(3)] for _ in range(3)]  # 3x3 board with stacks
        self.red_pieces = {'large': 2, 'medium': 2, 'small': 2}  # Red player's pieces
        self.yellow_pieces = {'large': 2, 'medium': 2, 'small': 2}  # Yellow player's pieces
        self.current_player = 'red'  # Start with red player
        self.selected_piece = None  # Currently selected piece
        self.selected_origin = None  # If selected from board, store its origin (row, col)
        self.game_over = False
        self.winner = None

        # Pygame setup
        pygame.init()
        self.width, self.height = 800, 600
        self.screen = pygame.display.set_mode((self.width, self.height))
        pygame.display.set_caption("Gobblet Gobblers")
        self.cell_size = 100
        self.board_x = (self.width - 3 * self.cell_size) // 2
        self.board_y = (self.height - 3 * self.cell_size) // 2
        self.panel_x = 50
        self.panel_y = 50
        self.panel_width = 200
        self.colors = {
            'WHITE': (255, 255, 255),
            'BLACK': (0, 0, 0),
            'RED': (255, 0, 0),
            'YELLOW': (255, 255, 0),
            'GRAY': (200, 200, 200),
            'HIGHLIGHT': (0, 255, 0)
        }

    def check_win(self, color):
        """
        Check if the given player (color) has won the game.
        
        A player wins if they have a piece on the top of all three cells in a row,
        column, or diagonal.

        Parameters:
        color (str): The color of the player ('red' or 'yellow').

        Returns:
        bool: True if the player has won, False otherwise.
        """
        for i in range(3):
            if all(self.board[i][j] and self.board[i][j][-1].color == color for j in range(3)):
                return True
            if all(self.board[j][i] and self.board[j][i][-1].color == color for j in range(3)):
                return True
        if all(self.board[i][i] and self.board[i][i][-1].color == color for i in range(3)):
            return True
        if all(self.board[i][2-i] and self.board[i][2-i][-1].color == color for i in range(3)):
            return True
        return False

    def draw_board(self):
        """
        Draw the game board, including the cells, pieces, and player panel.

        This function:
        - Draws the 3x3 grid.
        - Displays the pieces stacked in each cell.
        - Shows the current player's turn and available pieces.
        - Highlights the winning message if the game is over.
        """
        self.screen.fill(self.colors['WHITE'])
        for row in range(3):
            for col in range(3):
                x = self.board_x + col * self.cell_size
                y = self.board_y + row * self.cell_size
                pygame.draw.rect(
                    self.screen,
                    self.colors['BLACK'],
                    (x, y, self.cell_size,
                     self.cell_size), 2
                )
                cell = self.board[row][col]
                for idx, piece in enumerate(cell):
                    color = self.colors['RED'] if piece.color == 'red' else self.colors['YELLOW']
                    radius = 40 if piece.size == 'large' else 30 if piece.size == 'medium' else 20
                    offset = (len(cell) - idx - 1) * 5
                    pygame.draw.circle(
                        self.screen,
                        color,
                        (x + self.cell_size//2, y + self.cell_size//2 - offset),
                        radius
                    )

        current_color=self.colors['RED'] if self.current_player == 'red' else self.colors['YELLOW']
        pygame.draw.rect(
            self.screen,
            self.colors['GRAY'],
            (self.panel_x, self.panel_y, self.panel_width, 300)
        )
        font = pygame.font.Font(None, 24)
        text = font.render(f"{self.current_player}'s turn", True, current_color)
        self.screen.blit(text, (self.panel_x + 10, self.panel_y + 10))
        available = self.red_pieces if self.current_player == 'red' else self.yellow_pieces
        y_offset = self.panel_y + 50
        for size in ['large', 'medium', 'small']:
            count = available[size]
            radius = 40 if size == 'large' else 30 if size == 'medium' else 20
            pygame.draw.circle(
                self.screen,
                current_color,
                (self.panel_x + 50, y_offset + radius), radius
            )
            text = font.render(f"x{count}", True, self.colors['BLACK'])
            self.screen.blit(text, (self.panel_x + 100, y_offset))
            y_offset += 2 * radius + 20

        if self.game_over:
            font = pygame.font.Font(None, 74)
            text = font.render(f"{self.winner} wins!", True, self.colors['BLACK'])
            text_rect = text.get_rect(center=(self.width//2, self.height//2))
            self.screen.blit(text, text_rect)

    def get_cell_from_pos(self, pos):
        """
        Determine the board cell corresponding to the given screen position.

        Parameters:
        pos (tuple): (x, y) coordinates of the mouse click.

        Returns:
        tuple or None: (row, col) if the position is inside the board, otherwise None.
        """
        x, y = pos
        if (self.board_x <= x < self.board_x + 3 * self.cell_size and
            self.board_y <= y < self.board_y + 3 * self.cell_size):
            row = (y - self.board_y) // self.cell_size
            col = (x - self.board_x) // self.cell_size
            return (row, col)
        return None

    def handle_click(self, pos):
        """
        Handle a mouse click event by selecting a piece or making a move.

        - If clicking on the player panel, selects a new piece from the available pieces.
        - If clicking on the board, selects a piece or attempts to move the selected piece.
        - Ensures moves follow the game rules (e.g., larger pieces can gobble smaller ones).
        - Checks for a win condition after a move.

        Parameters:
        pos (tuple): (x, y) coordinates of the mouse click.
        """
        if self.game_over:
            return

        # Check if click is on the panel to select a new piece from reserves.
        if (self.panel_x <= pos[0] <= self.panel_x + self.panel_width and
            self.panel_y <= pos[1] <= self.panel_y + 300):
            available = self.red_pieces if self.current_player == 'red' else self.yellow_pieces
            sizes = ['large', 'medium', 'small']
            y_offset = self.panel_y + 50
            for size in sizes:
                radius = 40 if size == 'large' else 30 if size == 'medium' else 20
                if available[size] > 0:
                    circle_center = (self.panel_x + 50, y_offset + radius)
                    if (pos[0]-circle_center[0])**2+(pos[1]-circle_center[1])**2<=radius ** 2:
                        self.selected_piece = Piece(self.current_player, size)
                        self.selected_origin = None  # Piece comes from panel
                        return
                y_offset += 2 * radius + 20

        # Otherwise, if click is on a board cell:
        cell = self.get_cell_from_pos(pos)
        if cell is not None:
            row, col = cell
            dest_stack = self.board[row][col]

            # If a piece is already selected, attempt a move.
            if self.selected_piece:
                moving_piece = self.selected_piece
                # If destination cell has a piece of the current player...
                if dest_stack and dest_stack[-1].color == self.current_player:
                    # If clicking on the same cell the piece was selected from, cancel selection.
                    if self.selected_origin is not None and (row, col) == self.selected_origin:
                        self.selected_piece = None
                        self.selected_origin = None
                        return
                    # Allow gobbling (even if same colour) if the moving piece is larger.
                    if size_order[moving_piece.size] > size_order[dest_stack[-1].size]:
                        pass  # Continue to move the piece.
                    else:
                        # If move is not valid, update selection to that piece.
                        self.selected_piece = dest_stack[-1]
                        self.selected_origin = (row, col)
                        return

                # For empty cells or cells with opponent pieces, check move validity.
                elif dest_stack and size_order[moving_piece.size]<=size_order[dest_stack[-1].size]:
                    # If the destination is not gobbleable, do nothing.
                    return

                # Perform the move.
                if self.selected_origin is not None:
                    origin_row, origin_col = self.selected_origin
                    if self.board[origin_row][origin_col]:
                        if self.board[origin_row][origin_col][-1] == moving_piece:
                            self.board[origin_row][origin_col].pop()
                else:
                    # Piece came from the panel; reduce available count.
                    available=self.red_pieces if self.current_player=='red' else self.yellow_pieces
                    available[moving_piece.size] -= 1

                dest_stack.append(moving_piece)
                opponent = 'yellow' if self.current_player == 'red' else 'red'
                if self.check_win(opponent):
                    self.game_over = True
                    self.winner = opponent
                elif self.check_win(self.current_player):
                    self.game_over = True
                    self.winner = self.current_player
                else:
                    self.current_player = opponent

                self.selected_piece = None
                self.selected_origin = None
                return

            # No piece is currently selected. If the clicked cell has a piece belonging
            # to the current player, select it for moving.
            if dest_stack and dest_stack[-1].color == self.current_player:
                self.selected_piece = dest_stack[-1]
                self.selected_origin = (row, col)
                return

    def run(self):
        """
        Start the game loop, handling user input and rendering the board.

        - Listens for quit events to close the game.
        - Detects mouse clicks and calls `handle_click()`.
        - Updates the board display.
        """

        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    self.handle_click(event.pos)

            self.draw_board()
            pygame.display.flip()
        pygame.quit()

if __name__ == "__main__":
    game = GobbletGobblers()
    game.run()
