import pygame

# Define size hierarchy
size_order = {'large': 3, 'medium': 2, 'small': 1}

class Piece:
    def __init__(self, color, size):
        self.color = color
        self.size = size

class GobbletGobblers:
    def __init__(self):
        self.board = [[[] for _ in range(3)] for _ in range(3)]  # 3x3 board with stacks
        self.red_pieces = {'large': 2, 'medium': 2, 'small': 2}  # Red player's pieces
        self.yellow_pieces = {'large': 2, 'medium': 2, 'small': 2}  # Yellow player's pieces
        self.current_player = 'red'  # Start with red player
        self.selected_piece = None  # Currently selected piece
        self.selected_origin = None  # If selected from board, store its origin (row, col)
        self.game_over = False
        self.winner = None

        # Pygame setup
        pygame.init()
        self.WIDTH, self.HEIGHT = 800, 600
        self.screen = pygame.display.set_mode((self.WIDTH, self.HEIGHT))
        pygame.display.set_caption("Gobblet Gobblers")
        self.CELL_SIZE = 100
        self.BOARD_X = (self.WIDTH - 3 * self.CELL_SIZE) // 2
        self.BOARD_Y = (self.HEIGHT - 3 * self.CELL_SIZE) // 2
        self.PANEL_X = 50
        self.PANEL_Y = 50
        self.PANEL_WIDTH = 200
        self.colors = {
            'WHITE': (255, 255, 255),
            'BLACK': (0, 0, 0),
            'RED': (255, 0, 0),
            'YELLOW': (255, 255, 0),
            'GRAY': (200, 200, 200),
            'HIGHLIGHT': (0, 255, 0)
        }

    def check_win(self, color):
        for i in range(3):
            if all(self.board[i][j] and self.board[i][j][-1].color == color for j in range(3)):
                return True
            if all(self.board[j][i] and self.board[j][i][-1].color == color for j in range(3)):
                return True
        if all(self.board[i][i] and self.board[i][i][-1].color == color for i in range(3)):
            return True
        if all(self.board[i][2-i] and self.board[i][2-i][-1].color == color for i in range(3)):
            return True
        return False

    def draw_board(self):
        self.screen.fill(self.colors['WHITE'])
        for row in range(3):
            for col in range(3):
                x = self.BOARD_X + col * self.CELL_SIZE
                y = self.BOARD_Y + row * self.CELL_SIZE
                pygame.draw.rect(
                    self.screen,
                    self.colors['BLACK'],
                    (x, y, self.CELL_SIZE,
                     self.CELL_SIZE), 2
                )
                cell = self.board[row][col]
                for idx, piece in enumerate(cell):
                    color = self.colors['RED'] if piece.color == 'red' else self.colors['YELLOW']
                    radius = 40 if piece.size == 'large' else 30 if piece.size == 'medium' else 20
                    offset = (len(cell) - idx - 1) * 5
                    pygame.draw.circle(
                        self.screen,
                        color,
                        (x + self.CELL_SIZE//2, y + self.CELL_SIZE//2 - offset),
                        radius
                    )

        current_color=self.colors['RED'] if self.current_player == 'red' else self.colors['YELLOW']
        pygame.draw.rect(
            self.screen,
            self.colors['GRAY'],
            (self.PANEL_X, self.PANEL_Y, self.PANEL_WIDTH, 300)
        )
        font = pygame.font.Font(None, 24)
        text = font.render(f"{self.current_player}'s turn", True, current_color)
        self.screen.blit(text, (self.PANEL_X + 10, self.PANEL_Y + 10))
        available = self.red_pieces if self.current_player == 'red' else self.yellow_pieces
        y_offset = self.PANEL_Y + 50
        for size in ['large', 'medium', 'small']:
            count = available[size]
            radius = 40 if size == 'large' else 30 if size == 'medium' else 20
            pygame.draw.circle(
                self.screen,
                current_color,
                (self.PANEL_X + 50, y_offset + radius), radius
            )
            text = font.render(f"x{count}", True, self.colors['BLACK'])
            self.screen.blit(text, (self.PANEL_X + 100, y_offset))
            y_offset += 2 * radius + 20

        if self.game_over:
            font = pygame.font.Font(None, 74)
            text = font.render(f"{self.winner} wins!", True, self.colors['BLACK'])
            text_rect = text.get_rect(center=(self.WIDTH//2, self.HEIGHT//2))
            self.screen.blit(text, text_rect)

    def get_cell_from_pos(self, pos):
        x, y = pos
        if (self.BOARD_X <= x < self.BOARD_X + 3 * self.CELL_SIZE and
            self.BOARD_Y <= y < self.BOARD_Y + 3 * self.CELL_SIZE):
            row = (y - self.BOARD_Y) // self.CELL_SIZE
            col = (x - self.BOARD_X) // self.CELL_SIZE
            return (row, col)
        return None

    def handle_click(self, pos):
        if self.game_over:
            return

        # Check if click is on the panel to select a new piece from reserves.
        if (self.PANEL_X <= pos[0] <= self.PANEL_X + self.PANEL_WIDTH and
            self.PANEL_Y <= pos[1] <= self.PANEL_Y + 300):
            available = self.red_pieces if self.current_player == 'red' else self.yellow_pieces
            sizes = ['large', 'medium', 'small']
            y_offset = self.PANEL_Y + 50
            for size in sizes:
                radius = 40 if size == 'large' else 30 if size == 'medium' else 20
                if available[size] > 0:
                    circle_center = (self.PANEL_X + 50, y_offset + radius)
                    if(pos[0]-circle_center[0])**2+(pos[1]-circle_center[1])**2<=radius** 2:
                        self.selected_piece = Piece(self.current_player, size)
                        self.selected_origin = None  # Piece comes from panel
                        return
                y_offset += 2 * radius + 20

        # Otherwise, if click is on a board cell:
        cell = self.get_cell_from_pos(pos)
        if cell is not None:
            row, col = cell
            dest_stack = self.board[row][col]

            # If a piece is already selected, attempt a move.
            if self.selected_piece:
                moving_piece = self.selected_piece
                # If destination cell has a piece of the current player...
                if dest_stack and dest_stack[-1].color == self.current_player:
                    # If clicking on the same cell the piece was selected from, cancel selection.
                    if self.selected_origin is not None and (row, col) == self.selected_origin:
                        self.selected_piece = None
                        self.selected_origin = None
                        return
                    # Allow gobbling (even if same colour) if the moving piece is larger.
                    if size_order[moving_piece.size] > size_order[dest_stack[-1].size]:
                        pass  # Continue to move the piece.
                    else:
                        # If move is not valid, update selection to that piece.
                        self.selected_piece = dest_stack[-1]
                        self.selected_origin = (row, col)
                        return

                # For empty cells or cells with opponent pieces, check move validity.
                elif dest_stack and size_order[moving_piece.size]<=size_order[dest_stack[-1].size]:
                    # If the destination is not gobbleable, do nothing.
                    return

                # Perform the move.
                if self.selected_origin is not None:
                    origin_row, origin_col = self.selected_origin
                    if self.board[origin_row][origin_col]:
                            if self.board[origin_row][origin_col][-1] == moving_piece:
                                self.board[origin_row][origin_col].pop()
                else:
                    # Piece came from the panel; reduce available count.
                    available=self.red_pieces if self.current_player=='red' else self.yellow_pieces
                    available[moving_piece.size] -= 1

                dest_stack.append(moving_piece)
                opponent = 'yellow' if self.current_player == 'red' else 'red'
                if self.check_win(opponent):
                    self.game_over = True
                    self.winner = opponent
                elif self.check_win(self.current_player):
                    self.game_over = True
                    self.winner = self.current_player
                else:
                    self.current_player = opponent

                self.selected_piece = None
                self.selected_origin = None
                return

            else:
                # No piece is currently selected. If the clicked cell has a piece belonging
                # to the current player, select it for moving.
                if dest_stack and dest_stack[-1].color == self.current_player:
                    self.selected_piece = dest_stack[-1]
                    self.selected_origin = (row, col)
                    return

    def run(self):
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    self.handle_click(event.pos)

            self.draw_board()
            pygame.display.flip()
        pygame.quit()

if __name__ == "__main__":
    game = GobbletGobblers()
    game.run()
