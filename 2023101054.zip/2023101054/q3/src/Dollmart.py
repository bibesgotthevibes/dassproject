import os
import json
import uuid
import datetime
import random
from enum import Enum
from abc import ABC, abstractmethod
import threading
import time
import datetime
# Constants
DATA_DIR = "data"
USERS_FILE = os.path.join(DATA_DIR, "users.json")
PRODUCTS_FILE = os.path.join(DATA_DIR, "products.json")
ORDERS_FILE = os.path.join(DATA_DIR, "orders.json")
COUPONS_FILE = os.path.join(DATA_DIR, "coupons.json")

# Enums


class UserType(Enum):
    INDIVIDUAL = "individual"
    RETAIL = "retail"

class OrderStatus(Enum):
    PLACED = "Placed"
    PROCESSING = "Processing"
    SHIPPED = "Shipped"
    DELIVERED = "Delivered"
    CANCELLED = "Cancelled"

class DeliveryMethod(Enum):
    STANDARD = "standard"
    EXPRESS = "express"

# Abstract Classes
class User(ABC):
    def __init__(self, user_id, name, email, password, address, phone):
        self.user_id = user_id
        self.name = name
        self.email = email
        self.password = password
        self.address = address
        self.phone = phone
        self.cart = {}
        self.order_history = []
        self.coupons = []

    @abstractmethod
    def get_price_multiplier(self):
        pass

    def to_dict(self):
        return {
            "user_id": self.user_id,
            "name": self.name,
            "email": self.email,
            "password": self.password,
            "address": self.address,
            "phone": self.phone,
            "cart": self.cart,
            "order_history": self.order_history,
            "coupons": self.coupons,
            "type": self.__class__.__name__
        }

class AdminUser(User):
    def __init__(self, user_id, name, email, password, address, phone):
        super().__init__(user_id, name, email, password, address, phone)

    def get_price_multiplier(self):
        return 1.0

    def to_dict(self):
        data = super().to_dict()
        data["type"] = "Admin"
        return data

class IndividualCustomer(User):
    def __init__(self, user_id, name, email, password, address, phone):
        super().__init__(user_id, name, email, password, address, phone)
        self.loyalty_points = 0  # New attribute for loyalty points

    def get_price_multiplier(self):
        return 1.0  # No automatic discount; discount via loyalty redemption

    def to_dict(self):
        data = super().to_dict()
        data["loyalty_points"] = self.loyalty_points
        return data

class RetailCustomer(User):
    def __init__(self, user_id, name, email, password, address, phone, business_license):
        super().__init__(user_id, name, email, password, address, phone)
        self.business_license = business_license

    def get_price_multiplier(self):
        # Always use standard pricing here; discount applied at checkout.
        return 1.0

    def to_dict(self):
        data = super().to_dict()
        data["business_license"] = self.business_license
        return data


class Product:
    def __init__(self, product_id, name, description, price, category, stock):
        self.product_id = product_id
        self.name = name
        self.description = description
        self.price = price
        self.category = category
        self.stock = stock

    def to_dict(self):
        return {
            "product_id": self.product_id,
            "name": self.name,
            "description": self.description,
            "price": self.price,
            "category": self.category,
            "stock": self.stock
        }

class Order:
    def __init__(self, order_id, user_id, items, total_price, address, delivery_method, status=OrderStatus.PLACED):
        self.order_id = order_id
        self.user_id = user_id
        self.items = items  # Dictionary: {product_id: quantity}
        self.total_price = total_price
        self.address = address
        self.delivery_method = delivery_method
        self.status = status
        self.date_placed = datetime.datetime.now().isoformat()
        self.tracking_info = self._generate_tracking_info()

    def _generate_tracking_info(self):
        return f"DM-{random.randint(1000000, 9999999)}"

    def update_status(self, new_status):
        self.status = new_status

    def to_dict(self):
        return {
            "order_id": self.order_id,
            "user_id": self.user_id,
            "items": self.items,
            "total_price": self.total_price,
            "address": self.address,
            "delivery_method": self.delivery_method.value,
            "status": self.status.value,
            "date_placed": self.date_placed,
            "tracking_info": self.tracking_info
        }

class Coupon:
    def __init__(self, coupon_id, code, discount_percent, expiry_date, min_purchase=0):
        self.coupon_id = coupon_id
        self.code = code
        self.discount_percent = discount_percent
        self.expiry_date = expiry_date
        self.min_purchase = min_purchase
        self.is_used = False

    def is_valid(self, purchase_amount):
        if self.is_used:
            return False

        expiry = datetime.datetime.fromisoformat(self.expiry_date)
        now = datetime.datetime.now()

        if now > expiry:
            return False

        if purchase_amount < self.min_purchase:
            return False

        return True

    def to_dict(self):
        return {
            "coupon_id": self.coupon_id,
            "code": self.code,
            "discount_percent": self.discount_percent,
            "expiry_date": self.expiry_date,
            "min_purchase": self.min_purchase,
            "is_used": self.is_used
        }

# Managers
class DataManager:
    @staticmethod
    def ensure_data_directory():
        if not os.path.exists(DATA_DIR):
            os.makedirs(DATA_DIR)

    @staticmethod
    def load_data(file_path, default=None):
        DataManager.ensure_data_directory()

        if default is None:
            default = []

        if not os.path.exists(file_path):
            with open(file_path, 'w') as f:
                json.dump(default, f)
            return default

        try:
            with open(file_path, 'r') as f:
                return json.load(f)
        except json.JSONDecodeError:
            return default

    @staticmethod
    def save_data(file_path, data):
        DataManager.ensure_data_directory()

        with open(file_path, 'w') as f:
            json.dump(data, f, indent=2)
class UserManager:
    @staticmethod
    def load_users():
        users_data = DataManager.load_data(USERS_FILE)
        users = {}

        for user_data in users_data:
            # Safely retrieve "user_id" and generate one if missing.
            user_id = user_data.get("user_id")
            if not user_id:
                user_id = str(uuid.uuid4())
                user_data["user_id"] = user_id  # Optionally update the data

            # Retrieve the user type; default to "IndividualCustomer" if missing.
            user_type = user_data.get("type", "IndividualCustomer")

            if user_type == "IndividualCustomer":
                user = IndividualCustomer(
                    user_id,
                    user_data.get("name", ""),
                    user_data.get("email", ""),
                    user_data.get("password", ""),
                    user_data.get("address", ""),
                    user_data.get("phone", "")
                )
            elif user_type == "RetailCustomer":
                user = RetailCustomer(
                    user_id,
                    user_data.get("name", ""),
                    user_data.get("email", ""),
                    user_data.get("password", ""),
                    user_data.get("address", ""),
                    user_data.get("phone", ""),
                    user_data.get("business_license", "")
                )
            elif user_type == "Admin":
                # Create an admin user; if any field is missing, use defaults.
                user = AdminUser(
                    user_id,
                    user_data.get("name", "Admin"),
                    user_data.get("email", "admin"),
                    user_data.get("password", "admin"),
                    user_data.get("address", ""),
                    user_data.get("phone", "")
                )
            else:
                continue

            # Retrieve additional keys safely
            user.cart = user_data.get("cart", {})
            user.order_history = user_data.get("order_history", [])
            user.coupons = user_data.get("coupons", [])
            users[user.user_id] = user

        return users

    @staticmethod
    def save_users(users):
        users_data = [user.to_dict() for user in users.values()]
        DataManager.save_data(USERS_FILE, users_data)

    @staticmethod
    def register_user(name, email, password, address, phone, user_type, business_license=None):
        users = UserManager.load_users()

        # Check if email already exists
        for user in users.values():
            if user.email == email:
                return None, "Email already registered"

        user_id = str(uuid.uuid4())

        if user_type == UserType.INDIVIDUAL:
            user = IndividualCustomer(user_id, name, email, password, address, phone)
        else:
            if not business_license:
                return None, "Business license required for retail customers"
            user = RetailCustomer(user_id, name, email, password, address, phone, business_license)

        users[user_id] = user
        UserManager.save_users(users)

        return user, "Registration successful"

    @staticmethod
    def login(email, password):
        # Special admin login: if email and password are "admin", return an AdminUser.
        if email.lower() == "admin" and password == "admin":
            admin_user = AdminUser("admin", "Admin", "admin", "admin", "N/A", "N/A")
            return admin_user, "Login successful"

        users = UserManager.load_users()
        for user in users.values():
            if user.email == email and user.password == password:
                return user, "Login successful"

        return None, "Invalid email or password"

    @staticmethod
    def get_user(user_id):
        users = UserManager.load_users()
        return users.get(user_id)

    @staticmethod
    def update_user(user):
        users = UserManager.load_users()
        users[user.user_id] = user
        UserManager.save_users(users)


class ProductManager:
    @staticmethod
    def load_products():
        products_data = DataManager.load_data(PRODUCTS_FILE)
        products = {}

        for product_data in products_data:
            product = Product(
                product_data["product_id"],
                product_data["name"],
                product_data["description"],
                product_data["price"],
                product_data["category"],
                product_data["stock"]
            )
            products[product.product_id] = product

        return products

    @staticmethod
    def save_products(products):
        products_data = [product.to_dict() for product in products.values()]
        DataManager.save_data(PRODUCTS_FILE, products_data)

    @staticmethod
    def add_product(name, description, price, category, stock):
        products = ProductManager.load_products()

        product_id = str(uuid.uuid4())
        product = Product(product_id, name, description, price, category, stock)

        products[product_id] = product
        ProductManager.save_products(products)

        return product

    @staticmethod
    def get_product(product_id):
        products = ProductManager.load_products()
        return products.get(product_id)

    @staticmethod
    def search_products(query, category=None):
        products = ProductManager.load_products()
        results = []

        query = query.lower()

        for product in products.values():
            if (query in product.name.lower() or query in product.description.lower()) and \
               (not category or product.category == category):
                results.append(product)

        return results

    @staticmethod
    def get_products_by_category(category):
        products = ProductManager.load_products()
        return [product for product in products.values() if product.category == category]

    @staticmethod
    def get_all_categories():
        products = ProductManager.load_products()
        return sorted(set(product.category for product in products.values()))

    @staticmethod
    def update_product_stock(product_id, quantity_change):
        products = ProductManager.load_products()

        if product_id not in products:
            return False

        product = products[product_id]

        if product.stock + quantity_change < 0:
            return False

        product.stock += quantity_change
        ProductManager.save_products(products)

        return True
class OrderManager:
    @staticmethod
    def load_orders():
        orders_data = DataManager.load_data(ORDERS_FILE)
        orders = {}

        for order_data in orders_data:
            # Safely retrieve "order_id"; generate one if missing.
            order_id = order_data.get("order_id")
            if not order_id:
                order_id = str(uuid.uuid4())
                order_data["order_id"] = order_id  # Optionally update the loaded data

            user_id = order_data.get("user_id", "")
            items = order_data.get("items", {})
            total_price = order_data.get("total_price", 0)
            address = order_data.get("address", "")
            delivery_method = order_data.get("delivery_method", "standard")
            status = order_data.get("status", "Placed")

            order = Order(
                order_id,
                user_id,
                items,
                total_price,
                address,
                DeliveryMethod(delivery_method),
                OrderStatus(status)
            )
            order.date_placed = order_data.get("date_placed", "")
            order.tracking_info = order_data.get("tracking_info", "")
            orders[order.order_id] = order

        return orders

    @staticmethod
    def save_orders(orders):
        orders_data = [order.to_dict() for order in orders.values()]
        DataManager.save_data(ORDERS_FILE, orders_data)

    @staticmethod
    def place_order(user, delivery_method, applied_coupon=None):
        if not user.cart:
            return None, "Cart is empty"

        products = ProductManager.load_products()

        # Check product availability
        for product_id, quantity in user.cart.items():
            if product_id not in products:
                return None, f"Product {product_id} not found"
            product = products[product_id]
            if product.stock < quantity:
                return None, f"Not enough stock for {product.name}"

        # Calculate total price
        total_price = 0
        for product_id, quantity in user.cart.items():
            product = products[product_id]
            total_price += product.price * quantity * user.get_price_multiplier()

        # (Coupon logic removed)

        # Create order
        order_id = str(uuid.uuid4())
        order = Order(
            order_id,
            user.user_id,
            user.cart.copy(),
            total_price,
            user.address,
            delivery_method
        )

        # Update stock
        for product_id, quantity in user.cart.items():
            ProductManager.update_product_stock(product_id, -quantity)

        # Update user information: add order to history and clear cart.
        user.order_history.append(order_id)
        user.cart = {}
        UserManager.update_user(user)

        # Award loyalty points for IndividualCustomers (1 point per $10 spent)
        if isinstance(user, IndividualCustomer):
            loyalty_award = int(total_price)
            user.loyalty_points += loyalty_award
            UserManager.update_user(user)

        # Save order
        orders = OrderManager.load_orders()
        orders[order_id] = order
        OrderManager.save_orders(orders)

        return order, "Order placed successfully"


    @staticmethod
    def get_order(order_id):
        orders = OrderManager.load_orders()
        return orders.get(order_id)

    @staticmethod
    def get_user_orders(user_id):
        orders = OrderManager.load_orders()
        return [order for order in orders.values() if order.user_id == user_id]

    @staticmethod
    def update_order_status(order_id, new_status):
        orders = OrderManager.load_orders()

        if order_id not in orders:
            return False

        orders[order_id].update_status(new_status)
        OrderManager.save_orders(orders)

        return True

def auto_update_order_status():
    while True:
        orders = OrderManager.load_orders()
        now = datetime.datetime.now()
        updated = False

        for order in orders.values():
            # Skip if date_placed is missing or empty
            if not order.date_placed:
                continue

            try:
                placed_time = datetime.datetime.fromisoformat(order.date_placed)
            except ValueError:
                print(f"Invalid date_placed format for order {order.order_id}: {order.date_placed}")
                continue

            # For testing, we use very short intervals:
            if order.status == OrderStatus.PLACED and now >= placed_time + datetime.timedelta(seconds=30):
                order.update_status(OrderStatus.PROCESSING)
                print(f"Order {order.order_id} updated to PROCESSING")
                updated = True
            elif order.status == OrderStatus.PROCESSING and now >= placed_time + datetime.timedelta(seconds=60):
                order.update_status(OrderStatus.SHIPPED)
                print(f"Order {order.order_id} updated to SHIPPED")
                updated = True
            elif order.status == OrderStatus.SHIPPED and now >= placed_time + datetime.timedelta(seconds=90):
                order.update_status(OrderStatus.DELIVERED)
                print(f"Order {order.order_id} updated to DELIVERED")
                updated = True

        if updated:
            OrderManager.save_orders(orders)
        time.sleep(10)  # Check every 10 seconds

# Start the background thread (make sure to call this at program startup)
threading.Thread(target=auto_update_order_status, daemon=True).start()
class DollmartCLI:
    def __init__(self):
        self.current_user = None
        self.initialize_data()

    def initialize_data(self):
        # Sample categories (used for products)
        categories = ["Groceries", "Electronics", "Personal Care", "Home Goods", "Clothing"]
        products = ProductManager.load_products()
        if not products:
            sample_products = [
                ("Milk", "Fresh cow's milk, 1 liter", 2.99, "Groceries", 100),
                ("Bread", "Whole wheat bread, 500g", 1.99, "Groceries", 50),
                ("Eggs", "Free-range eggs, dozen", 3.49, "Groceries", 40),
                ("Smartphone", "Latest model with 128GB storage", 699.99, "Electronics", 15),
                ("Laptop", "15-inch laptop with 8GB RAM", 899.99, "Electronics", 10),
                ("Headphones", "Wireless over-ear headphones", 129.99, "Electronics", 20),
                ("Shampoo", "Moisturizing shampoo, 500ml", 5.99, "Personal Care", 30),
                ("Toothpaste", "Whitening toothpaste, 100ml", 3.99, "Personal Care", 45),
                ("Towel Set", "Set of 4 cotton bath towels", 24.99, "Home Goods", 25),
                ("Bedding Set", "Queen size cotton bedding set", 49.99, "Home Goods", 15),
                ("T-shirt", "Cotton t-shirt, various colors", 12.99, "Clothing", 30),
                ("Jeans", "Classic fit denim jeans", 34.99, "Clothing", 20)
            ]
            for name, description, price, category, stock in sample_products:
                ProductManager.add_product(name, description, price, category, stock)

    def display_menu(self):
        if not self.current_user:
            print("\n===== Welcome to Dollmart E-Market =====")
            print("1. Login")
            print("2. Register")
            print("3. Browse Products")
            print("4. Search Products")
            print("0. Exit")
        else:
            if isinstance(self.current_user, AdminUser):
                print("\n===== Welcome, Admin =====")
                print("1. Manage Products")
                print("2. View Orders")
                print("3. Logout")
                print("0. Exit")
            else:
                print(f"\n===== Welcome, {self.current_user.name} =====")
                print("1. Browse Products")
                print("2. Search Products")
                print("3. View Cart")
                print("4. View Orders")
                print("5. View Loyalty Points")  # New loyalty points option
                print("6. Logout")
                print("0. Exit")



    def handle_input(self, choice):
        if not self.current_user:
            if choice == "1":
                self.login()
            elif choice == "2":
                self.register()
            elif choice == "3":
                self.browse_products()
            elif choice == "4":
                self.search_products()
            elif choice == "0":
                return False
        else:
            if isinstance(self.current_user, AdminUser):
                if choice == "1":
                    self.admin_menu()
                elif choice == "2":
                    self.view_orders()  # Admin view of all orders.
                elif choice == "3":
                    self.logout()
                elif choice == "0":
                    return False
            else:
                if choice == "1":
                    self.browse_products()
                elif choice == "2":
                    self.search_products()
                elif choice == "3":
                    self.view_cart()
                elif choice == "4":
                    self.view_orders()
                elif choice == "5":
                    self.view_loyalty_points()
                elif choice == "6":
                    self.logout()
                elif choice == "0":
                    return False
        return True



    def login(self):
        print("\n===== Login =====")
        email = input("Email: ")
        password = input("Password: ")
        user, message = UserManager.login(email, password)
        print(message)
        if user:
            self.current_user = user

    def register(self):
        print("\n===== Register =====")
        name = input("Name: ")
        email = input("Email: ")
        password = input("Password: ")
        address = input("Address: ")
        phone = input("Phone: ")
        print("User Type:")
        print("1. Individual")
        print("2. Retail")
        user_type_choice = input("Choice: ")
        if user_type_choice == "1":
            user_type = UserType.INDIVIDUAL
            business_license = None
        elif user_type_choice == "2":
            user_type = UserType.RETAIL
            business_license = input("Business License Number: ")
        else:
            print("Invalid choice")
            return
        user, message = UserManager.register_user(name, email, password, address, phone, user_type, business_license)
        print(message)
        if user:
            self.current_user = user

    def logout(self):
        self.current_user = None
        print("Logged out successfully")

    # ------------- Admin Functions -------------
    def admin_menu(self):
        while True:
            print("\n===== Admin Menu =====")
            print("1. Add Product")
            print("2. Remove Product")
            print("3. Update Product Stock")
            print("4. View All Products")
            print("5. Logout")
            print("0. Back")
            choice = input("Enter your choice: ")
            if choice == "1":
                self.admin_add_product()
            elif choice == "2":
                self.admin_remove_product()
            elif choice == "3":
                self.admin_update_stock()
            elif choice == "4":
                self.admin_view_products()
            elif choice == "5":
                self.logout()
                break
            elif choice == "0":
                break
            else:
                print("Invalid choice")

    def admin_add_product(self):
        print("\n===== Add Product =====")
        name = input("Name: ")
        description = input("Description: ")
        try:
            price = float(input("Price: "))
            stock = int(input("Stock: "))
        except ValueError:
            print("Invalid price or stock input")
            return
        category = input("Category: ")
        product = ProductManager.add_product(name, description, price, category, stock)
        print(f"Product added with ID: {product.product_id}")

    def admin_remove_product(self):
        print("\n===== Remove Product =====")
        product_id = input("Enter product ID to remove: ")
        products = ProductManager.load_products()
        if product_id in products:
            del products[product_id]
            ProductManager.save_products(products)
            print("Product removed")
        else:
            print("Product not found")

    def admin_update_stock(self):
        print("\n===== Update Product Stock =====")
        product_id = input("Enter product ID: ")
        products = ProductManager.load_products()
        if product_id in products:
            try:
                change = int(input("Enter stock change (positive to add, negative to subtract): "))
            except ValueError:
                print("Invalid number")
                return
            success = ProductManager.update_product_stock(product_id, change)
            if success:
                print("Product stock updated")
            else:
                print("Failed to update product stock")
        else:
            print("Product not found")

    def admin_view_products(self):
        print("\n===== All Products =====")
        products = ProductManager.load_products()
        for product in products.values():
            print(f"ID: {product.product_id}")
            print(f"Name: {product.name}")
            print(f"Description: {product.description}")
            print(f"Price: ${product.price:.2f}")
            print(f"Category: {product.category}")
            print(f"Stock: {product.stock}")
            print("---------------")
        input("Press Enter to continue...")

    # ------------- User Functions -------------
    def browse_products(self):
        print("\n===== Browse Products =====")
        categories = ProductManager.get_all_categories()
        for i, category in enumerate(categories, 1):
            print(f"{i}. {category}")
        print("0. Back")
        choice = input("Select category: ")
        if choice == "0":
            return
        try:
            category_index = int(choice) - 1
            if 0 <= category_index < len(categories):
                selected_category = categories[category_index]
                self.display_products(ProductManager.get_products_by_category(selected_category))
            else:
                print("Invalid choice")
        except ValueError:
            print("Invalid input")

    def search_products(self):
        print("\n===== Search Products =====")
        query = input("Search query: ")
        products = ProductManager.search_products(query)
        if not products:
            print("No products found")
            return
        self.display_products(products)

    def display_products(self, products):
        if not products:
            print("No products found")
            return
        print("\n===== Products =====")
        for i, product in enumerate(products, 1):
            price = product.price
            if self.current_user:
                price *= self.current_user.get_price_multiplier()
            print(f"{i}. {product.name} - ${price:.2f}")
            print(f"   Description: {product.description}")
            print(f"   Stock: {product.stock}")
            print()
        print("0. Back")
        if self.current_user and not isinstance(self.current_user, AdminUser):
            choice = input("Select product to add to cart (or 0 to go back): ")
            if choice == "0":
                return
            try:
                product_index = int(choice) - 1
                if 0 <= product_index < len(products):
                    selected_product = products[product_index]
                    self.add_to_cart(selected_product)
                else:
                    print("Invalid choice")
            except ValueError:
                print("Invalid input")

    def add_to_cart(self, product):
        print(f"\n===== Add {product.name} to Cart =====")
        try:
            quantity = int(input("Quantity: "))
            if quantity <= 0:
                print("Quantity must be positive")
                return
            if quantity > product.stock:
                print("Not enough stock available")
                return
            if product.product_id in self.current_user.cart:
                self.current_user.cart[product.product_id] += quantity
            else:
                self.current_user.cart[product.product_id] = quantity
            UserManager.update_user(self.current_user)
            print(f"{quantity} x {product.name} added to cart")
        except ValueError:
            print("Invalid input")

    def view_cart(self):
        print("\n===== Cart =====")
        if not self.current_user.cart:
            print("Your cart is empty")
            return
        products = ProductManager.load_products()
        total = 0
        for product_id, quantity in self.current_user.cart.items():
            if product_id in products:
                product = products[product_id]
                price = product.price * self.current_user.get_price_multiplier()
                item_total = price * quantity
                total += item_total
                print(f"{product.name} - {quantity} x ${price:.2f} = ${item_total:.2f}")
        print(f"\nTotal: ${total:.2f}")
        print("\n1. Checkout")
        print("2. Remove Item")
        print("0. Back")
        choice = input("Choice: ")
        if choice == "1":
            self.checkout()
        elif choice == "2":
            self.remove_from_cart()

    def remove_from_cart(self):
        print("\n===== Remove from Cart =====")
        products = ProductManager.load_products()
        cart_items = []
        for i, (product_id, quantity) in enumerate(self.current_user.cart.items(), 1):
            if product_id in products:
                product = products[product_id]
                price = product.price * self.current_user.get_price_multiplier()
                item_total = price * quantity
                print(f"{i}. {product.name} - {quantity} x ${price:.2f} = ${item_total:.2f}")
                cart_items.append(product_id)
        print("0. Back")
        choice = input("Select item to remove: ")
        if choice == "0":
            return
        try:
            item_index = int(choice) - 1
            if 0 <= item_index < len(cart_items):
                product_id = cart_items[item_index]
                quantity = int(input("Quantity to remove (0 for all): "))
                if quantity == 0 or quantity >= self.current_user.cart[product_id]:
                    del self.current_user.cart[product_id]
                else:
                    self.current_user.cart[product_id] -= quantity
                UserManager.update_user(self.current_user)
                print("Item removed from cart")
            else:
                print("Invalid choice")
        except ValueError:
            print("Invalid input")

    def checkout(self):
        print("\n===== Checkout =====")
        products = ProductManager.load_products()
        total = 0
        for product_id, quantity in self.current_user.cart.items():
            if product_id in products:
                product = products[product_id]
                price = product.price  # Use standard price
                item_total = price * quantity
                total += item_total
                print(f"{product.name} - {quantity} x ${price:.2f} = ${item_total:.2f}")
        print(f"\nSubtotal: ${total:.2f}")

        # For RetailCustomers, apply a constant 15% discount.
        if isinstance(self.current_user, RetailCustomer):
            retail_discount = total * 0.15
            total -= retail_discount
            print(f"Retail discount (15%): -${retail_discount:.2f}")
            print(f"New total: ${total:.2f}")
        # For IndividualCustomers, offer loyalty redemption if they have at least 100 points.
        elif isinstance(self.current_user, IndividualCustomer) and getattr(self.current_user, 'loyalty_points', 0) >= 100:
            print(f"You have {self.current_user.loyalty_points} loyalty points.")
            print("Loyalty Redemption Tiers:")
            print("  100 points => $10 discount")
            print("  200 points => 10% discount")
            print("  300 points => 15% discount")
            print("  500 points => 25% discount (max per order)")
            redeem = input("Redeem your loyalty points? (y/n): ")
            if redeem.lower() == "y":
                discount, points_used = self.calculate_loyalty_discount(total, self.current_user.loyalty_points)
                if discount > 0:
                    total -= discount
                    print(f"Loyalty discount applied: -${discount:.2f} (redeemed {points_used} points)")
                    print(f"New total after loyalty redemption: ${total:.2f}")
                    self.current_user.loyalty_points -= points_used
                    UserManager.update_user(self.current_user)
                else:
                    print("Not enough loyalty points to redeem a discount.")

        print("\nDelivery Method:")
        print("1. Standard (Free)")
        print("2. Express (+$10.00)")
        delivery_choice = input("Choice: ")
        if delivery_choice == "1":
            delivery_method = DeliveryMethod.STANDARD
        elif delivery_choice == "2":
            delivery_method = DeliveryMethod.EXPRESS
            total += 10.0
            print(f"New total with Express delivery: ${total:.2f}")
        else:
            print("Invalid choice, defaulting to Standard delivery")
            delivery_method = DeliveryMethod.STANDARD

        confirm = input("\nConfirm order? (y/n): ")
        if confirm.lower() == "y":
            order, message = OrderManager.place_order(self.current_user, delivery_method, None)
            print(message)
            if order:
                print(f"Order ID: {order.order_id}")
                print(f"Tracking Number: {order.tracking_info}")
        else:
            print("Order cancelled")


    def view_orders(self):
        print("\n===== Order History =====")
        # If admin, show all orders; otherwise, show user's orders.
        if isinstance(self.current_user, AdminUser):
            orders = OrderManager.load_orders()
        else:
            orders = {oid: OrderManager.get_order(oid) for oid in self.current_user.order_history}
        products = ProductManager.load_products()
        if not orders:
            print("No orders found")
            return
        i = 1
        order_ids = []
        for order in orders.values():
            if order is None:
                continue
            print(f"{i}. Order ID: {order.order_id}")
            print(f"   Date: {order.date_placed}")
            print(f"   Status: {order.status.value}")
            print(f"   Total: ${order.total_price:.2f}")
            print(f"   Tracking: {order.tracking_info}")
            print("   Items:")
            for product_id, quantity in order.items.items():
                if product_id in products:
                    product = products[product_id]
                    print(f"     - {product.name} x {quantity}")
            print()
            order_ids.append(order.order_id)
            i += 1
        print("0. Back")
        choice = input("Select order for more details (or 0 to go back): ")
        if choice == "0":
            return
        try:
            order_index = int(choice) - 1
            if 0 <= order_index < len(order_ids):
                selected_order_id = order_ids[order_index]
                self.track_order(selected_order_id)
            else:
                print("Invalid choice")
        except ValueError:
            print("Invalid input")

    def track_order(self, order_id):
        order = OrderManager.get_order(order_id)
        if not order:
            print("Order not found")
            return
        print(f"\n===== Order #{order.order_id} Tracking =====")
        print(f"Status: {order.status.value}")
        print(f"Tracking Number: {order.tracking_info}")
        placed_time = datetime.datetime.fromisoformat(order.date_placed)
        simulated_delivery_delta = datetime.timedelta(seconds=90)
        estimated_delivery_time = placed_time + simulated_delivery_delta
        now = datetime.datetime.now()
        if order.status == OrderStatus.PLACED:
            print("Your order has been received and is being processed.")
        elif order.status == OrderStatus.PROCESSING:
            print("Your order is being prepared for shipping.")
        elif order.status == OrderStatus.SHIPPED:
            print("Your order is on the way!")
            if estimated_delivery_time > now:
                time_left = estimated_delivery_time - now
                print(f"Time left for delivery: {str(time_left).split('.')[0]}")
            else:
                print("Your order should have been delivered by now!")
        elif order.status == OrderStatus.DELIVERED:
            print("Your order has been delivered.")
            print(f"Delivered at: {estimated_delivery_time.strftime('%H:%M:%S')}")
            time_taken = estimated_delivery_time - placed_time
            print(f"Time taken for delivery: {str(time_taken).split('.')[0]}")
        elif order.status == OrderStatus.CANCELLED:
            print("This order has been cancelled.")
        input("\nPress Enter to continue...")

    def view_coupons(self):
        print("\n===== Your Coupons =====")
        if not self.current_user.coupons:
            print("You have no coupons")
            return
        coupons = CouponManager.load_coupons()
        valid_coupons = []
        for i, coupon_id in enumerate(self.current_user.coupons, 1):
            if coupon_id in coupons:
                coupon = coupons[coupon_id]
                if not coupon.is_used:
                    expiry = datetime.datetime.fromisoformat(coupon.expiry_date)
                    now = datetime.datetime.now()
                    if now <= expiry:
                        print(f"{i}. Code: {coupon.code}")
                        print(f"   Discount: {coupon.discount_percent}%")
                        print(f"   Minimum Purchase: ${coupon.min_purchase:.2f}")
                        print(f"   Expires: {expiry.strftime('%Y-%m-%d')}")
                        print()
                        valid_coupons.append(coupon)
        if not valid_coupons:
            print("You have no valid coupons")
        input("Press Enter to continue...")

    def view_loyalty_points(self):
        # Only available for IndividualCustomers.
        if isinstance(self.current_user, IndividualCustomer):
            print(f"\nYou have {self.current_user.loyalty_points} loyalty points.")
        else:
            print("\nLoyalty points are only available for Individual Customers.")
        input("Press Enter to continue...")

    def calculate_loyalty_discount(self, total, loyalty_points):
        """
        Calculates the discount based on loyalty points.
        The customer can redeem up to 500 points per order.

        Tiers:
          - 100 points: $10 discount
          - 200 points: 10% discount
          - 300 points: 15% discount
          - 500 points: 25% discount
        Returns a tuple: (discount, points_used)
        """
        max_redeemable = 500
        redeemable_points = min(loyalty_points, max_redeemable)
        if redeemable_points >= 500:
            discount = total * 0.25
            points_used = 500
        elif redeemable_points >= 300:
            discount = total * 0.15
            points_used = 300
        elif redeemable_points >= 200:
            discount = total * 0.10
            points_used = 200
        elif redeemable_points >= 100:
            discount = 10.0  # flat $10 discount
            points_used = 100
        else:
            discount = 0
            points_used = 0
        return discount, points_used

    def run(self):
        running = True
        while running:
            self.display_menu()
            choice = input("Enter your choice: ")
            running = self.handle_input(choice)

class CouponManager:
    @staticmethod
    def load_coupons():
        coupons_data = DataManager.load_data(COUPONS_FILE)
        coupons = {}

        for coupon_data in coupons_data:
            coupon = Coupon(
                coupon_data["coupon_id"],
                coupon_data["code"],
                coupon_data["discount_percent"],
                coupon_data["expiry_date"],
                coupon_data["min_purchase"]
            )
            coupon.is_used = coupon_data["is_used"]
            coupons[coupon.coupon_id] = coupon

        return coupons

    @staticmethod
    def save_coupons(coupons):
        coupons_data = [coupon.to_dict() for coupon in coupons.values()]
        DataManager.save_data(COUPONS_FILE, coupons_data)

    @staticmethod
    def generate_coupon(discount_percent=10, min_purchase=0):
        coupons = CouponManager.load_coupons()

        coupon_id = str(uuid.uuid4())
        code = f"DM{random.randint(1000, 9999)}"

        # Set expiry date to 30 days from now
        expiry_date = (datetime.datetime.now() + datetime.timedelta(days=30)).isoformat()

        coupon = Coupon(coupon_id, code, discount_percent, expiry_date, min_purchase)

        coupons[coupon_id] = coupon
        CouponManager.save_coupons(coupons)

        return coupon

    @staticmethod
    def get_coupon(coupon_id):
        coupons = CouponManager.load_coupons()
        return coupons.get(coupon_id)

    @staticmethod
    def get_coupon_by_code(code):
        coupons = CouponManager.load_coupons()

        for coupon in coupons.values():
            if coupon.code == code and not coupon.is_used:
                return coupon

        return None

    @staticmethod
    def mark_coupon_used(coupon_id):
        coupons = CouponManager.load_coupons()

        if coupon_id not in coupons:
            return False

        coupons[coupon_id].is_used = True
        CouponManager.save_coupons(coupons)

        return True

# CLI Interfaceclass DollmartCLI:
    def __init__(self):
        self.current_user = None
        self.initialize_data()

    def initialize_data(self):
        # Sample categories (used for products)
        categories = ["Groceries", "Electronics", "Personal Care", "Home Goods", "Clothing"]
        # Check if we have products already
        products = ProductManager.load_products()
        if not products:
            # Add sample products
            sample_products = [
                ("Milk", "Fresh cow's milk, 1 liter", 2.99, "Groceries", 100),
                ("Bread", "Whole wheat bread, 500g", 1.99, "Groceries", 50),
                ("Eggs", "Free-range eggs, dozen", 3.49, "Groceries", 40),
                ("Smartphone", "Latest model with 128GB storage", 699.99, "Electronics", 15),
                ("Laptop", "15-inch laptop with 8GB RAM", 899.99, "Electronics", 10),
                ("Headphones", "Wireless over-ear headphones", 129.99, "Electronics", 20),
                ("Shampoo", "Moisturizing shampoo, 500ml", 5.99, "Personal Care", 30),
                ("Toothpaste", "Whitening toothpaste, 100ml", 3.99, "Personal Care", 45),
                ("Towel Set", "Set of 4 cotton bath towels", 24.99, "Home Goods", 25),
                ("Bedding Set", "Queen size cotton bedding set", 49.99, "Home Goods", 15),
                ("T-shirt", "Cotton t-shirt, various colors", 12.99, "Clothing", 30),
                ("Jeans", "Classic fit denim jeans", 34.99, "Clothing", 20)
            ]
            for name, description, price, category, stock in sample_products:
                ProductManager.add_product(name, description, price, category, stock)

    def display_menu(self):
        if not self.current_user:
            print("\n===== Welcome to Dollmart E-Market =====")
            print("1. Login")
            print("2. Register")
            print("3. Browse Products")
            print("4. Search Products")
            print("0. Exit")
        else:
            # If the current user is an admin, show admin-specific options
            if isinstance(self.current_user, AdminUser):
                print("\n===== Welcome, Admin =====")
                print("1. Manage Products")
                print("2. View Orders")
                print("3. Logout")
                print("0. Exit")
            else:
                print(f"\n===== Welcome, {self.current_user.name} =====")
                print("1. Browse Products")
                print("2. Search Products")
                print("3. View Cart")
                print("4. View Orders")
                print("5. View Coupons")
                print("6. Logout")
                print("0. Exit")

    def handle_input(self, choice):
        if not self.current_user:
            if choice == "1":
                self.login()
            elif choice == "2":
                self.register()
            elif choice == "3":
                self.browse_products()
            elif choice == "4":
                self.search_products()
            elif choice == "0":
                return False
        else:
            if isinstance(self.current_user, AdminUser):
                if choice == "1":
                    self.admin_menu()
                elif choice == "2":
                    self.view_orders()  # Optionally, you can create a separate admin order view.
                elif choice == "3":
                    self.logout()
                elif choice == "0":
                    return False
            else:
                if choice == "1":
                    self.browse_products()
                elif choice == "2":
                    self.search_products()
                elif choice == "3":
                    self.view_cart()
                elif choice == "4":
                    self.view_orders()
                elif choice == "5":
                    self.view_coupons()
                elif choice == "6":
                    self.logout()
                elif choice == "0":
                    return False
        return True

    def login(self):
        print("\n===== Login =====")
        email = input("Email: ")
        password = input("Password: ")
        user, message = UserManager.login(email, password)
        print(message)
        if user:
            self.current_user = user

    def register(self):
        print("\n===== Register =====")
        name = input("Name: ")
        email = input("Email: ")
        password = input("Password: ")
        address = input("Address: ")
        phone = input("Phone: ")
        print("User Type:")
        print("1. Individual")
        print("2. Retail")
        user_type_choice = input("Choice: ")
        if user_type_choice == "1":
            user_type = UserType.INDIVIDUAL
            business_license = None
        elif user_type_choice == "2":
            user_type = UserType.RETAIL
            business_license = input("Business License Number: ")
        else:
            print("Invalid choice")
            return
        user, message = UserManager.register_user(name, email, password, address, phone, user_type, business_license)
        print(message)
        if user:
            self.current_user = user

    def logout(self):
        self.current_user = None
        print("Logged out successfully")

    # ---------------- Admin Functions ----------------
    def admin_menu(self):
        while True:
            print("\n===== Admin Menu =====")
            print("1. Add Product")
            print("2. Remove Product")
            print("3. Update Product Stock")
            print("4. View All Products")
            print("5. Logout")
            print("0. Back")
            choice = input("Enter your choice: ")
            if choice == "1":
                self.admin_add_product()
            elif choice == "2":
                self.admin_remove_product()
            elif choice == "3":
                self.admin_update_stock()
            elif choice == "4":
                self.admin_view_products()
            elif choice == "5":
                self.logout()
                break
            elif choice == "0":
                break
            else:
                print("Invalid choice")

    def admin_add_product(self):
        print("\n===== Add Product =====")
        name = input("Name: ")
        description = input("Description: ")
        try:
            price = float(input("Price: "))
            stock = int(input("Stock: "))
        except ValueError:
            print("Invalid price or stock input")
            return
        category = input("Category: ")
        product = ProductManager.add_product(name, description, price, category, stock)
        print(f"Product added with ID: {product.product_id}")

    def admin_remove_product(self):
        print("\n===== Remove Product =====")
        product_id = input("Enter product ID to remove: ")
        products = ProductManager.load_products()
        if product_id in products:
            del products[product_id]
            ProductManager.save_products(products)
            print("Product removed")
        else:
            print("Product not found")

    def admin_update_stock(self):
        print("\n===== Update Product Stock =====")
        product_id = input("Enter product ID: ")
        products = ProductManager.load_products()
        if product_id in products:
            try:
                change = int(input("Enter stock change (positive to add, negative to subtract): "))
            except ValueError:
                print("Invalid number")
                return
            success = ProductManager.update_product_stock(product_id, change)
            if success:
                print("Product stock updated")
            else:
                print("Failed to update product stock")
        else:
            print("Product not found")

    def admin_view_products(self):
        print("\n===== All Products =====")
        products = ProductManager.load_products()
        for product in products.values():
            print(f"ID: {product.product_id}")
            print(f"Name: {product.name}")
            print(f"Description: {product.description}")
            print(f"Price: ${product.price:.2f}")
            print(f"Category: {product.category}")
            print(f"Stock: {product.stock}")
            print("---------------")
        input("Press Enter to continue...")

    # ---------------- User Functions ----------------
    def browse_products(self):
        print("\n===== Browse Products =====")
        categories = ProductManager.get_all_categories()
        for i, category in enumerate(categories, 1):
            print(f"{i}. {category}")
        print("0. Back")
        choice = input("Select category: ")
        if choice == "0":
            return
        try:
            category_index = int(choice) - 1
            if 0 <= category_index < len(categories):
                selected_category = categories[category_index]
                self.display_products(ProductManager.get_products_by_category(selected_category))
            else:
                print("Invalid choice")
        except ValueError:
            print("Invalid input")

    def search_products(self):
        print("\n===== Search Products =====")
        query = input("Search query: ")
        products = ProductManager.search_products(query)
        if not products:
            print("No products found")
            return
        self.display_products(products)

    def display_products(self, products):
        if not products:
            print("No products found")
            return
        print("\n===== Products =====")
        for i, product in enumerate(products, 1):
            price = product.price
            if self.current_user:
                price *= self.current_user.get_price_multiplier()
            print(f"{i}. {product.name} - ${price:.2f}")
            print(f"   Description: {product.description}")
            print(f"   Stock: {product.stock}")
            print()
        print("0. Back")
        if self.current_user and not isinstance(self.current_user, AdminUser):
            choice = input("Select product to add to cart (or 0 to go back): ")
            if choice == "0":
                return
            try:
                product_index = int(choice) - 1
                if 0 <= product_index < len(products):
                    selected_product = products[product_index]
                    self.add_to_cart(selected_product)
                else:
                    print("Invalid choice")
            except ValueError:
                print("Invalid input")

    def add_to_cart(self, product):
        print(f"\n===== Add {product.name} to Cart =====")
        try:
            quantity = int(input("Quantity: "))
            if quantity <= 0:
                print("Quantity must be positive")
                return
            if quantity > product.stock:
                print("Not enough stock available")
                return
            if product.product_id in self.current_user.cart:
                self.current_user.cart[product.product_id] += quantity
            else:
                self.current_user.cart[product.product_id] = quantity
            UserManager.update_user(self.current_user)
            print(f"{quantity} x {product.name} added to cart")
        except ValueError:
            print("Invalid input")

    def view_cart(self):
        print("\n===== Cart =====")
        if not self.current_user.cart:
            print("Your cart is empty")
            return
        products = ProductManager.load_products()
        total = 0
        for product_id, quantity in self.current_user.cart.items():
            if product_id in products:
                product = products[product_id]
                price = product.price * self.current_user.get_price_multiplier()
                item_total = price * quantity
                total += item_total
                print(f"{product.name} - {quantity} x ${price:.2f} = ${item_total:.2f}")
        print(f"\nTotal: ${total:.2f}")
        print("\n1. Checkout")
        print("2. Remove Item")
        print("0. Back")
        choice = input("Choice: ")
        if choice == "1":
            self.checkout()
        elif choice == "2":
            self.remove_from_cart()

    def remove_from_cart(self):
        print("\n===== Remove from Cart =====")
        products = ProductManager.load_products()
        cart_items = []
        for i, (product_id, quantity) in enumerate(self.current_user.cart.items(), 1):
            if product_id in products:
                product = products[product_id]
                price = product.price * self.current_user.get_price_multiplier()
                item_total = price * quantity
                print(f"{i}. {product.name} - {quantity} x ${price:.2f} = ${item_total:.2f}")
                cart_items.append(product_id)
        print("0. Back")
        choice = input("Select item to remove: ")
        if choice == "0":
            return
        try:
            item_index = int(choice) - 1
            if 0 <= item_index < len(cart_items):
                product_id = cart_items[item_index]
                quantity = int(input("Quantity to remove (0 for all): "))
                if quantity == 0 or quantity >= self.current_user.cart[product_id]:
                    del self.current_user.cart[product_id]
                else:
                    self.current_user.cart[product_id] -= quantity
                UserManager.update_user(self.current_user)
                print("Item removed from cart")
            else:
                print("Invalid choice")
        except ValueError:
            print("Invalid input")

    def checkout(self):
        print("\n===== Checkout =====")
        products = ProductManager.load_products()
        total = 0
        for product_id, quantity in self.current_user.cart.items():
            if product_id in products:
                product = products[product_id]
                price = product.price  # Use standard price
                item_total = price * quantity
                total += item_total
                print(f"{product.name} - {quantity} x ${price:.2f} = ${item_total:.2f}")
        print(f"\nSubtotal: ${total:.2f}")

        # For RetailCustomers, apply a constant 15% discount.
        if isinstance(self.current_user, RetailCustomer):
            retail_discount = total * 0.15
            total -= retail_discount
            print(f"Retail discount (15%): -${retail_discount:.2f}")
            print(f"New total: ${total:.2f}")
        # For IndividualCustomers, offer loyalty redemption if they have at least 100 points.
        elif isinstance(self.current_user, IndividualCustomer) and getattr(self.current_user, 'loyalty_points', 0) >= 100:
            print(f"You have {self.current_user.loyalty_points} loyalty points.")
            print("Loyalty Redemption Tiers:")
            print("  100 points => $10 discount")
            print("  200 points => 10% discount")
            print("  300 points => 15% discount")
            print("  500 points => 25% discount (max per order)")
            redeem = input("Redeem your loyalty points? (y/n): ")
            if redeem.lower() == "y":
                discount, points_used = self.calculate_loyalty_discount(total, self.current_user.loyalty_points)
                if discount > 0:
                    total -= discount
                    print(f"Loyalty discount applied: -${discount:.2f} (redeemed {points_used} points)")
                    print(f"New total after loyalty redemption: ${total:.2f}")
                    self.current_user.loyalty_points -= points_used
                    UserManager.update_user(self.current_user)
                else:
                    print("Not enough loyalty points to redeem a discount.")

        print("\nDelivery Method:")
        print("1. Standard (Free)")
        print("2. Express (+$10.00)")
        delivery_choice = input("Choice: ")
        if delivery_choice == "1":
            delivery_method = DeliveryMethod.STANDARD
        elif delivery_choice == "2":
            delivery_method = DeliveryMethod.EXPRESS
            total += 10.0
            print(f"New total with Express delivery: ${total:.2f}")
        else:
            print("Invalid choice, defaulting to Standard delivery")
            delivery_method = DeliveryMethod.STANDARD

        confirm = input("\nConfirm order? (y/n): ")
        if confirm.lower() == "y":
            order, message = OrderManager.place_order(self.current_user, delivery_method, None)
            print(message)
            if order:
                print(f"Order ID: {order.order_id}")
                print(f"Tracking Number: {order.tracking_info}")
        else:
            print("Order cancelled")


    def view_orders(self):
        print("\n===== Order History =====")
        if not self.current_user.order_history:
            print("You have no orders")
            return
        orders = OrderManager.load_orders()
        products = ProductManager.load_products()
        for i, order_id in enumerate(self.current_user.order_history, 1):
            if order_id in orders:
                order = orders[order_id]
                print(f"{i}. Order ID: {order.order_id}")
                print(f"   Date: {order.date_placed}")
                print(f"   Status: {order.status.value}")
                print(f"   Total: ${order.total_price:.2f}")
                print(f"   Tracking: {order.tracking_info}")
                print("   Items:")
                for product_id, quantity in order.items.items():
                    if product_id in products:
                        product = products[product_id]
                        print(f"     - {product.name} x {quantity}")
                print()
        print("0. Back")
        choice = input("Select order for more details (or 0 to go back): ")
        if choice == "0":
            return
        try:
            order_index = int(choice) - 1
            if 0 <= order_index < len(self.current_user.order_history):
                selected_order_id = self.current_user.order_history[order_index]
                self.track_order(selected_order_id)
            else:
                print("Invalid choice")
        except ValueError:
            print("Invalid input")

    def track_order(self, order_id):
        order = OrderManager.get_order(order_id)
        if not order:
            print("Order not found")
            return
        print(f"\n===== Order #{order.order_id} Tracking =====")
        print(f"Status: {order.status.value}")
        print(f"Tracking Number: {order.tracking_info}")
        placed_time = datetime.datetime.fromisoformat(order.date_placed)
        simulated_delivery_delta = datetime.timedelta(seconds=90)
        estimated_delivery_time = placed_time + simulated_delivery_delta
        now = datetime.datetime.now()
        if order.status == OrderStatus.PLACED:
            print("Your order has been received and is being processed.")
        elif order.status == OrderStatus.PROCESSING:
            print("Your order is being prepared for shipping.")
        elif order.status == OrderStatus.SHIPPED:
            print("Your order is on the way!")
            if estimated_delivery_time > now:
                time_left = estimated_delivery_time - now
                print(f"Time left for delivery: {str(time_left).split('.')[0]}")
            else:
                print("Your order should have been delivered by now!")
        elif order.status == OrderStatus.DELIVERED:
            print("Your order has been delivered.")
            print(f"Delivered at: {estimated_delivery_time.strftime('%H:%M:%S')}")
            time_taken = estimated_delivery_time - placed_time
            print(f"Time taken for delivery: {str(time_taken).split('.')[0]}")
        elif order.status == OrderStatus.CANCELLED:
            print("This order has been cancelled.")
        input("\nPress Enter to continue...")

    def view_coupons(self):
        print("\n===== Your Coupons =====")
        if not self.current_user.coupons:
            print("You have no coupons")
            return
        coupons = CouponManager.load_coupons()
        valid_coupons = []
        for i, coupon_id in enumerate(self.current_user.coupons, 1):
            if coupon_id in coupons:
                coupon = coupons[coupon_id]
                if not coupon.is_used:
                    expiry = datetime.datetime.fromisoformat(coupon.expiry_date)
                    now = datetime.datetime.now()
                    if now <= expiry:
                        print(f"{i}. Code: {coupon.code}")
                        print(f"   Discount: {coupon.discount_percent}%")
                        print(f"   Minimum Purchase: ${coupon.min_purchase:.2f}")
                        print(f"   Expires: {expiry.strftime('%Y-%m-%d')}")
                        print()
                        valid_coupons.append(coupon)
        if not valid_coupons:
            print("You have no valid coupons")
        input("Press Enter to continue...")

    def run(self):
        running = True
        while running:
            self.display_menu()
            choice = input("Enter your choice: ")
            running = self.handle_input(choice)

def main():
    # Create data directory if it doesn't exist
    DataManager.ensure_data_directory()

    # Initialize CLI
    cli = DollmartCLI()
    cli.run()

if __name__ == "__main__":
    main()