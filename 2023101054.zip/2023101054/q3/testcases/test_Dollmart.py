import pytest
import os
import json
import shutil
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../src'))
from Dollmart import (
    UserManager, ProductManager, OrderManager, CouponManager,
    User, AdminUser, IndividualCustomer, RetailCustomer,
    Product, Order, Coupon,
    UserType, OrderStatus, DeliveryMethod,
    DataManager
)

# Test Data Constants
TEST_DATA_DIR = "test_data"
TEST_USERS_FILE = os.path.join(TEST_DATA_DIR, "users.json")
TEST_PRODUCTS_FILE = os.path.join(TEST_DATA_DIR, "products.json")
TEST_ORDERS_FILE = os.path.join(TEST_DATA_DIR, "orders.json")
TEST_COUPONS_FILE = os.path.join(TEST_DATA_DIR, "coupons.json")

@pytest.fixture(autouse=True)
def setup_test_environment(monkeypatch):
    # Modify data paths for testing
    monkeypatch.setattr('Dollmart.DATA_DIR', TEST_DATA_DIR)
    monkeypatch.setattr('Dollmart.USERS_FILE', TEST_USERS_FILE)
    monkeypatch.setattr('Dollmart.PRODUCTS_FILE', TEST_PRODUCTS_FILE)
    monkeypatch.setattr('Dollmart.ORDERS_FILE', TEST_ORDERS_FILE)
    monkeypatch.setattr('Dollmart.COUPONS_FILE', TEST_COUPONS_FILE)

    # Clean up any existing test data directory
    if os.path.exists(TEST_DATA_DIR):
        shutil.rmtree(TEST_DATA_DIR)

    # Create fresh test data directory
    os.makedirs(TEST_DATA_DIR)

    yield

    # Cleanup after tests
    try:
        if os.path.exists(TEST_DATA_DIR):
            shutil.rmtree(TEST_DATA_DIR)
    except Exception as e:
        print(f"Warning: Failed to cleanup test directory: {e}")

# User Management Tests
class TestUserManager:
    def test_register_individual_customer(self):
        user, message = UserManager.register_user(
            "John Doe",
            "john@example.com",
            "password123",
            "123 Main St",
            "1234567890",
            UserType.INDIVIDUAL
        )
        assert user is not None
        assert isinstance(user, IndividualCustomer)
        assert message == "Registration successful"
        assert user.name == "John Doe"
        assert user.email == "john@example.com"

    def test_register_retail_customer(self):
        user, message = UserManager.register_user(
            "Store Corp",
            "store@example.com",
            "password123",
            "456 Business Ave",
            "9876543210",
            UserType.RETAIL,
            "BL123456"
        )
        assert user is not None
        assert isinstance(user, RetailCustomer)
        assert message == "Registration successful"
        assert user.business_license == "BL123456"

    def test_login_success(self):
        # First register a user
        UserManager.register_user(
            "Test User",
            "test@example.com",
            "password123",
            "Test Address",
            "1234567890",
            UserType.INDIVIDUAL
        )

        # Then try to login
        user, message = UserManager.login("test@example.com", "password123")
        assert user is not None
        assert message == "Login successful"

    def test_admin_login(self):
        user, message = UserManager.login("admin", "admin")
        assert isinstance(user, AdminUser)
        assert message == "Login successful"

    def test_register_duplicate_email(self):
        # First registration
        UserManager.register_user(
            "First User",
            "duplicate@example.com",
            "password123",
            "Address",
            "1234567890",
            UserType.INDIVIDUAL
        )

        # Second registration with same email
        user, message = UserManager.register_user(
            "Second User",
            "duplicate@example.com",
            "password456",
            "Address",
            "0987654321",
            UserType.INDIVIDUAL
        )
        assert user is None
        assert message == "Email already registered"

    def test_login_invalid_credentials(self):
        user, message = UserManager.login("nonexistent@example.com", "wrongpassword")
        assert user is None
        assert message == "Invalid email or password"

# Product Management Tests
class TestProductManager:
    def test_add_product(self):
        product = ProductManager.add_product(
            "Test Product",
            "Test Description",
            9.99,
            "Test Category",
            10
        )
        assert product is not None
        assert product.name == "Test Product"
        assert product.price == 9.99
        assert product.stock == 10

    def test_search_products(self):
        ProductManager.add_product("Test Product 1", "Description 1", 9.99, "Category A", 10)
        ProductManager.add_product("Test Product 2", "Description 2", 19.99, "Category B", 20)

        results = ProductManager.search_products("Test")
        assert len(results) == 2

        results = ProductManager.search_products("Test", category="Category A")
        assert len(results) == 1

    def test_update_product_stock(self):
        product = ProductManager.add_product("Stock Test", "Test", 9.99, "Test", 10)
        assert ProductManager.update_product_stock(product.product_id, -5)
        updated_product = ProductManager.get_product(product.product_id)
        assert updated_product.stock == 5

    def test_update_product_stock_negative(self):
        product = ProductManager.add_product("Stock Test", "Test", 9.99, "Test", 10)
        # Try to reduce stock by more than available
        assert not ProductManager.update_product_stock(product.product_id, -15)
        updated_product = ProductManager.get_product(product.product_id)
        assert updated_product.stock == 10  # Stock should remain unchanged

    def test_search_products_no_results(self):
        results = ProductManager.search_products("NonexistentProduct")
        assert len(results) == 0

    def test_search_products_case_insensitive(self):
        ProductManager.add_product("Test Product", "Description", 9.99, "Test", 10)
        results = ProductManager.search_products("test")
        assert len(results) == 1
        results = ProductManager.search_products("TEST")
        assert len(results) == 1

# Order Management Tests
class TestOrderManager:
    @pytest.fixture
    def setup_user_and_product(self):
        user, _ = UserManager.register_user(
            "Order Test User",
            "order@test.com",
            "password123",
            "Test Address",
            "1234567890",
            UserType.INDIVIDUAL
        )
        product = ProductManager.add_product("Test Product", "Description", 9.99, "Test", 10)
        user.cart[product.product_id] = 2
        UserManager.update_user(user)
        return user, product

    def test_place_order(self, setup_user_and_product):
        user, product = setup_user_and_product
        order, message = OrderManager.place_order(user, DeliveryMethod.STANDARD)

        assert order is not None
        assert message == "Order placed successfully"
        assert order.total_price == 19.98  # 2 items at 9.99 each
        assert ProductManager.get_product(product.product_id).stock == 8

    def test_get_user_orders(self, setup_user_and_product):
        user, _ = setup_user_and_product
        OrderManager.place_order(user, DeliveryMethod.STANDARD)

        orders = OrderManager.get_user_orders(user.user_id)
        assert len(orders) == 1
        assert orders[0].user_id == user.user_id

    def test_place_order_empty_cart(self, setup_user_and_product):
        user, _ = setup_user_and_product
        user.cart = {}  # Empty the cart
        UserManager.update_user(user)

        order, message = OrderManager.place_order(user, DeliveryMethod.STANDARD)
        assert order is None
        assert message == "Cart is empty"

    def test_place_order_insufficient_stock(self, setup_user_and_product):
        user, product = setup_user_and_product
        user.cart[product.product_id] = 100  # Try to order more than available
        UserManager.update_user(user)

        order, message = OrderManager.place_order(user, DeliveryMethod.STANDARD)
        assert order is None
        assert message.startswith("Not enough stock")

    def test_order_status_tracking(self, setup_user_and_product):
        user, _ = setup_user_and_product
        order, _ = OrderManager.place_order(user, DeliveryMethod.STANDARD)

        assert order.status == OrderStatus.PLACED
        OrderManager.update_order_status(order.order_id, OrderStatus.PROCESSING)
        updated_order = OrderManager.get_order(order.order_id)
        assert updated_order.status == OrderStatus.PROCESSING

# Coupon Management Tests
# class TestCouponManager:
#     def test_generate_coupon(self):
#         coupon = CouponManager.generate_coupon(20, 50.0)
#         assert coupon is not None
#         assert coupon.discount_percent == 20
#         assert coupon.min_purchase == 50.0
#         assert not coupon.is_used

#     def test_mark_coupon_used(self):
#         coupon = CouponManager.generate_coupon()
#         assert CouponManager.mark_coupon_used(coupon.coupon_id)
#         updated_coupon = CouponManager.get_coupon(coupon.coupon_id)
#         assert updated_coupon.is_used

#     def test_expired_coupon(self):
#         coupons = CouponManager.load_coupons()
#         coupon = CouponManager.generate_coupon(20, 50.0)
#         # Set expiry date to yesterday
#         yesterday = (datetime.datetime.now() - datetime.timedelta(days=1)).isoformat()
#         coupon.expiry_date = yesterday
#         coupons[coupon.coupon_id] = coupon
#         CouponManager.save_coupons(coupons)

#         assert not coupon.is_valid(100.0)

#     def test_minimum_purchase_requirement(self):
#         coupon = CouponManager.generate_coupon(20, 100.0)
#         assert not coupon.is_valid(50.0)  # Below minimum purchase
#         assert coupon.is_valid(150.0)     # Above minimum purchase

#     def test_get_nonexistent_coupon(self):
#         coupon = CouponManager.get_coupon("nonexistent-id")
#         assert coupon is None

#     def test_get_coupon_by_code(self):
#         coupon = CouponManager.generate_coupon(20, 50.0)
#         found_coupon = CouponManager.get_coupon_by_code(coupon.code)
#         assert found_coupon is not None
#         assert found_coupon.coupon_id == coupon.coupon_id

# Data Management Tests
class TestDataManager:
    def test_load_nonexistent_file(self):
        test_file = os.path.join(TEST_DATA_DIR, "nonexistent.json")
        data = DataManager.load_data(test_file)
        assert data == []
        assert os.path.exists(test_file)

    def test_save_and_load_data(self):
        test_file = os.path.join(TEST_DATA_DIR, "test.json")
        test_data = {"test": "data"}
        DataManager.save_data(test_file, test_data)
        loaded_data = DataManager.load_data(test_file)
        assert loaded_data == test_data

if __name__ == '__main__':
    pytest.main([__file__])
